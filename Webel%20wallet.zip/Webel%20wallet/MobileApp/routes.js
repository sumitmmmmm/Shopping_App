import { Router, Scene } from 'react-native-router-flux'
import React from 'react';
import MenuPageScreen from '../MobileApp/Components/MenuPage/menuPage';
import PaymentPageScreen from '../MobileApp/Components/PaymentPage/paymentPage';
import LandingPageScreen from '../MobileApp/Components/landingPage/landingPage';
import TransactionHistoryScreen from '../MobileApp/Components/TransactionHistory/transactionHistory';
import AddMoneyScreen from './Components/addMoney/addMoney';
import RequestOverdraftScreen from './Components/requestOverdraft/requestOverdraft'
const Routes = () => (

    <Router>
       <Scene key = "root">
          <Scene key = "MenuPageScreen"  component = {MenuPageScreen} hideNavBar="true" />
          <Scene key = "PaymentPageScreen" component ={PaymentPageScreen} hideNavBar="true"/>
          <Scene key = "LandingPageScreen"  component = {LandingPageScreen} hideNavBar="true"/>
          <Scene key = "AddMoneyScreen"  component = {AddMoneyScreen} hideNavBar="true" />
          <Scene key = "RequestOverdraftScreen"  component = {RequestOverdraftScreen} hideNavBar="true" initial={true}/>
          {/* <Scene key = "LoginScreen" component ={LoginScreen} hideNavBar="true"/> */}
          {/* <Scene key = "LandingPage" component ={LandingPage} initial={true} hideNavBar="true"/> */}
          {/* <Scene key = "CitizenListScreen" component ={CitizenListScreen} hideNavBar="true" /> */}
          {/* <Scene key = "DeliverRation" component ={DeliverRation}  hideNavBar="true" /> */}
          {/* <Scene key = "CategorySelection" component ={CategorySelection} hideNavBar="true" /> */}
          <Scene key = "TransactionHistoryScreen"  component = {TransactionHistoryScreen} hideNavBar="true" />
       </Scene>
    </Router>
 )
 export default Routes