import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Bubbles, DoubleBounce, Bars, Pulse } from 'react-native-loader';
import Modal from 'react-native-modal';
import DatePicker from 'react-native-datepicker'
import global from '../global/globalConfiguration'

export default class LandingPage extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            modalDisplayerForLogin: false,
            modalDisplayerForRegister: false,
            mobileNumber: '',
            password: '',
            nameForRegister: '',
            mobileNumberForRegister: '',
            dobForRegister: '',
            passwordForRegister: '',
            confirmPasswordForRegister: '',
            OTPView: false,
            OTP: ''
        }
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    openModalForLogin = () => {
        this.setState({
            modalDisplayerForLogin: true
        })
    }

    openModalForRegister = () => {
        this.setState({
            modalDisplayerForRegister: true
        })
    }

    handleMobileNumber = (value) => {
        this.setState({
            mobileNumber: value
        })
    }

    handlePassword = (value) => {
        this.setState({
            password: value
        })
    }

    handleNameForRegister = (value) => {
        this.setState({
            nameForRegister: value
        })
    }

    handleMobileNumberForRegister = (value) => {
        this.setState({
            mobileNumberForRegister: value
        })
    }

    handlePasswordForRegister = (value) => {
        this.setState({
            passwordForRegister: value
        })
    }

    handleConfirmPasswordForRegister = (value) => {
        this.setState({
            confirmPasswordForRegister: value
        })
    }

    handleOTP = (value) => {
        this.setState({
            OTP: value
        })
    }

    submitLogin = () => {

        fetch(global.ipAddr + global.userReg, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                enrollmentID: this.state.mobileNumber
            })
        })
        .then(response => response.json())
        .then(message => {

            AsyncStorage.setItem("mobileNumber", this.state.mobileNumber)
            .then(res => {
                AsyncStorage.setItem("jwtToken", message.token)
                .then(res => {
                    this.setState({
                        modalDisplayerForLogin : false,
                    })
                    Actions.MenuPageScreen();
                })
            })
           
            
        })
        .catch(error => console.log(error))
       
    }

    modalForLogin = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#2C9E3F', borderRadius: 40, height: this.height*0.5}}>
                
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({modalDisplayerForLogin: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>

                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 16, fontWeight: 'bold', color: '#fff'}}>Enter Login Credentials</Text>
                </View>

                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Mobile No.</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Mobile Number'
                                value={this.state.mobileNumber}
                                onChangeText={this.handleMobileNumber}
                                keyboardType="number-pad"
                            />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Password</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Password'
                                value={this.state.password}
                                onChangeText={this.handlePassword}
                                secureTextEntry={true}
                            />
                        </View>
                    </View>

                </View>

                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.submitLogin} >
                    <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#2C9E3F'}}>Login</Text>
                </TouchableOpacity>
                </View>
            </View>
        )
    }

    modalForRegister = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#2C9E3F', borderRadius: 40, height: this.height*0.7}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({modalDisplayerForRegister: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>

                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 16, fontWeight: 'bold', color: '#fff'}}>Enter following details to Register</Text>
                </View>

                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>

                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Name</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Name'
                                value={this.state.nameForRegister}
                                onChangeText={this.handleNameForRegister}
                                
                            />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Mobile No.</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Mobile Number'
                                value={this.state.mobileNumberForRegister}
                                onChangeText={this.handleMobileNumberForRegister}
                                keyboardType="number-pad"
                            />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Enter DOB</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <DatePicker
                                style={{width: this.width*0.54, backgroundColor: '#fff', borderRadius: 10}}
                                date={this.state.dobForRegister}
                                mode="date"
                                placeholder="select DOB"
                                format="YYYY-MM-DD"
                                minDate="1990-05-01"
                                maxDate="2016-06-01"
                                confirmBtnText="Confirm"
                                cancelBtnText="Cancel"
                                customStyles={{
                                dateIcon: {
                                    position: 'absolute',
                                    left: 0,
                                    top: 4,
                                    marginLeft: 0,
                                    
                                },
                                dateInput: {
                                    marginLeft: 36,
                                    borderWidth: 0
                                }
                                // ... You can check the source to find the other keys.
                                }}
                                onDateChange={(date) => {this.setState({dobForRegister: date})}}
                            />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Password</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Password'
                                value={this.state.passwordForRegister}
                                onChangeText={this.handlePasswordForRegister}
                                secureTextEntry={true}
                            />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Confirm Password</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Confirm Password'
                                value={this.state.confirmPasswordForRegister}
                                onChangeText={this.handleConfirmPasswordForRegister}
                                secureTextEntry={true}
                            />
                        </View>
                    </View>

                </View>

                {this.state.OTPView == false ? 
                    <View style={{justifyContent: 'center', alignItems: 'center', flex: 4}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '10%'}}>
                            <Text style={{fontSize: 12, fontStyle: 'italic', color: '#fff', textAlign: 'center'}}>Click on the Buttom below to get OTP on registered mobile Number</Text>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.generateOTP}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#2C9E3F'}}>Get OTP</Text>
                            </TouchableOpacity>
                        </View>
                    </View>:null
            
                }

                {this.state.OTPView == true ? 
                    <View style={{flex: 4, justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingBottom: '3%'}}>
                            <Text style={{fontSize: 12, fontStyle: 'italic', fontWeight: 'bold', color: '#fff', textAlign: 'center'}}>Enter OTP to complete registration</Text>
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.06}}
                                placeholder='Enter OTP'
                                value={this.state.OTP}
                                onChangeText={this.handleOTP}
                                secureTextEntry={true}
                            />
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.submitOTP}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#2C9E3F'}}>Submit</Text>
                            </TouchableOpacity>
                        </View>
                    </View>:null
            
                }

                
            </View>
        )
    }

    generateOTP = () => {

        var correctOTP = Math.floor(100000 + Math.random() * 900000); 
        
        this.setState({
            correctOTP: correctOTP
        })
        this.registerUser(correctOTP);
    }

    registerUser = (correctOTP) => {

        fetch(global.ipAddr + global.userReg, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                enrollmentID: this.state.mobileNumberForRegister
            })
        })
        .then(response => response.json())
        .then(message => {
           
            console.log("MSG", message);
            if(message.success == true){
                this.setState({
                    OTPView: true,
                    token: message.token
                })
            }
            else if(message.success == false){
                alert("User is already registered. Please Login to continue")
            }

        
    })
    .catch(error => alert(error))
        
    }

    submitOTP = () => {

       
            fetch(global.ipAddr + global.createWallet, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': this.state.token
                },
                body: JSON.stringify({
                    "channelName": "mychannel",
                    "chaincodeId": "papercontract",
                    "walletNo": "1",
                    "balance": "0"                
                })
            
            })
            .then(response => response.json())
            .then(createWalletMessage => {
                console.log("Create Wallet MSG", createWalletMessage)
                if(createWalletMessage.success == true){
                    
                    alert('User successfully logged in.')
                }
                else{
                    alert('Error registering user. Please try again')
                }
                this.setState({
                    modalDisplayerForRegister: false,
                    OTPView: false
                })
            })
            .catch(error => alert("Error", error))
        

    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center'}}>
                <Image style={{ position: 'absolute', opacity: 0.4, width: this.width, height: this.height}} source={require('../../assets/backgroundImage.png')} />
                <View style={{justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: this.width*0.5, height: this.width*0.5}} source={require('../../assets/wb_govt.png')} />
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '15%', flexDirection: 'row'}}>
                <Text style={{fontSize: 45, fontWeight: 'bold', textAlign: 'center', color: '#003399'}}>Block</Text>
                    <Text style={{fontSize: 45, fontWeight: 'bold', textAlign: 'center', color: '#fff'}}>Pay</Text>
                </View>
               
                <View style={{justifyContent: 'center', alignItems: 'center', position: 'absolute', bottom: 0, flexDirection: 'row'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{height: this.height*0.06, width: this.width*0.35, borderRadius: 10, backgroundColor: '#2C9E3F', justifyContent: 'center', alignItems: 'center'}} onPress={this.openModalForLogin}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#fff', textAlign: 'center'}}>Login</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{height: this.height*0.06, width: this.width*0.35, borderRadius: 10, backgroundColor: '#2C9E3F', justifyContent: 'center', alignItems: 'center'}} onPress={this.openModalForRegister}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#fff'}}>Register</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <Modal
                    isVisible={this.state.modalDisplayerForLogin == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalForLogin()}
                </Modal>

                <Modal
                    isVisible={this.state.modalDisplayerForRegister == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalForRegister()}
                </Modal>
             
            </View>
        )
    }
}