import React from 'react';
import { Dimensions, Text, ScrollView ,View,Image,TouchableOpacity, AsyncStorage } from 'react-native';
import MenuPageStyle from './menuPageStyle';
import { Actions } from 'react-native-router-flux';
import global from '../global/globalConfiguration';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faHome, faBookOpen, faHandHolding, faBell, faSignOutAlt, faHandHoldingHeart, faMoneyCheck, faCashRegister } from '@fortawesome/free-solid-svg-icons';
// import MultiSelect from 'react-native-multiple-select';
import Footer from '../Footer/footer';
import Header from '../Header/header';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class MenuPageScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            availableBalance: ''
        }
        AsyncStorage.getItem("jwtToken")
        .then(token => {
            console.log("TOKES", token)
            fetch(global.ipAddr + global.getWalletBalance, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': token
                },
                body: JSON.stringify({
                    'channelName': 'mychannel',
                    'chaincodeId': 'papercontract',
                    'walletNo': '1'
                })
            })
            .then(response => response.json())
            .then(json => {
                console.log("JSSS", json)
                if(json.success == true){
                    let parsedData = JSON.parse(json.result)
                    this.setState({
                        availableBalance: parsedData.balance
                    })
                    
                }
                else{
                    this.setState({
                        availableBalance: "NA"
                    })
                    // alert("Cannot fetch balance details. Please try again after sometime")
                }
                
            })
            .catch(error => {
                this.setState({
                    availableBalance: "NA"
                })
                // alert("Cannot fetch balance details. Please try again after sometime")
            })
        })
    }

    addMoney = () => {
        Actions.AddMoneyScreen();
        
    }

    payMoney = () => {
        Actions.PaymentPageScreen();
        // alert("Money Paid.")
    }  

    requestOverDraft = () => {
        Actions.RequestOverdraftScreen();
    }

    render ( ) {
        
        return(
            <View style={{flex:1, backgroundColor: 'white'}}>
                <Header/>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/wb_govt.png')} />
                </View>
                <ScrollView style={{ marginTop:'0%'}}>
                    <View style={{flex: 5, flexDirection: 'row', marginRight: '2%'}}>
                        <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:0.05*height}}>
                            <TouchableOpacity onPress={this.addMoney} style={MenuPageStyle.buttonStyle}>
                            <FontAwesomeIcon icon={faCashRegister} size={60} style={{color:"#fff"}}/>
                                
                            </TouchableOpacity>
                            <Text style={MenuPageStyle.buttonTextForMenu}>Add Money</Text>
                        </View>
                        <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:0.05*height, borderColor:"red"}}>
                            <TouchableOpacity onPress={this.payMoney} style={MenuPageStyle.buttonStyle}>
                            <FontAwesomeIcon icon={faMoneyCheck} size={60} style={{color:"#fff"}}/>
                                
                            </TouchableOpacity>
                            <Text style={MenuPageStyle.buttonTextForMenu}>Pay Money</Text>
                        </View>
                        <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:0.05*height, borderColor:"red"}}>
                            <TouchableOpacity onPress={this.requestOverDraft} style={MenuPageStyle.buttonStyle}>
                            <FontAwesomeIcon icon={faHandHoldingHeart} size={60} style={{color:"#fff"}}/>
                                
                            </TouchableOpacity>
                            <Text style={MenuPageStyle.buttonTextForMenu}>Request Overdraft</Text>
                        </View>
                       
                    </View>
                    
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop:0.05*height}}>
                            <Text style={MenuPageStyle.buttonText}>Available Balance :  &#8377; {this.state.availableBalance} </Text>
                    </View>
                    
                </ScrollView>
                <Footer/>
            </View>
        )
    }
}

