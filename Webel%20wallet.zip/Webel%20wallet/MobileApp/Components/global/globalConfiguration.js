const global = {
    apiIpAddr: 'http://54.157.168.139:8545',
    sendMessage : "/Messages/sendMessage",
    ipAddr : "http://54.157.168.139:8545",
    userReg : "/users",
    createWallet: "/createWallet",
    addMoney: "/addMoney",
    addMoneyOther: "/addMoneyOther",
    transferMoney: "/transferMoney",
    getWalletBalance: "/getWalletBalance"

}

export default global;