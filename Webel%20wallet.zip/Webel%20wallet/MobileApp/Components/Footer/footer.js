import React, { Component } from 'react';
import {
  View,
  TouchableOpacity,
  Image, 
  Text,
  KeyboardAvoidingView,   
  AsyncStorage
} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faHome, faBookOpen, faHandHolding, faBell, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
// import RequestStatus from '../Government/RequestStatus/RequestStatus';
import FooterStyle from './footerStyle';
// import FooterStyle from '../registerProduct/FooterStyle';

const currentDate = new Date();
const date = currentDate.getDate()+'-'+(currentDate.getMonth()+1)+'-'+currentDate.getFullYear();

export default class Footer extends React.Component {
    constructor(props){
        super(props);
        

        this.state={
            // batchNumberForMessage: props.notificationMessageDisplay,
            visibleModal: null,
            footerResponse: {},
        }
        // console.log(this.state.batchNumberForMessage);
    }
    gotoMenupage = () => {
        Actions.MenuPageScreen();
    }
    goToPassBook = () => {
        Actions.TransactionHistoryScreen()
    }

    logout = () => {
        Actions.LandingPageScreen()
    }
    render() {
     
        
        
        return(
        <View style={FooterStyle.parentContainer}>
        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity onPress={this.gotoMenupage}>
                <FontAwesomeIcon icon={faHome} size={30} style={{color:"#337AFF"}}/>
            </TouchableOpacity>
        </View>
        
        <View style={FooterStyle.imageStyle} >
            <TouchableOpacity onPress={this.goToPassBook}>
                <FontAwesomeIcon icon={faBookOpen} size={30} style={{color:"#337AFF"}}/>
            </TouchableOpacity>
        </View>
       
        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity>
                <FontAwesomeIcon icon={faBell} size={30} style={{color:"#337AFF"}}/>
            </TouchableOpacity>
        </View>
        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity onPress={this.logout}>
                <FontAwesomeIcon icon={faSignOutAlt} size={30} style={{color:"#337AFF"}}/>
            </TouchableOpacity>
        </View>
        </View> 
        )
    }
  }