import React from 'react';
import { Dimensions, Text, ScrollView ,View,Image,TouchableOpacity, AsyncStorage } from 'react-native';
import TransactionHistoryStyle from './transactionHistoryStyle';
import { Actions } from 'react-native-router-flux';
import global from '../global/globalConfiguration'
import Header from '../Header/header';
import Footer from '../Footer/footer';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class TransactionHistoryScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            availableBalance: '',
            transactionHistory: [],
            transactionDetails : [
                {
                    name : "Saurabh Dargude",
                    amount : -500,
                    tnxHash : "f4184fc596403b9d638783cf57adfe4c75c605f6356fbc91338530e9831e9e16",
                    tnxDate : "April 25 2020",
                    tnxTime : "10:54:24"
                },
                {
                    name : "Sumit Maiti",
                    amount : -300,
                    tnxHash : "a1075db55d416d3ca199f55b6084e2115b9345e16c5cf302fc80e9d5fbf5d48d",
                    tnxDate : "April 24 2020",
                    tnxTime : "12:34:54"
                },
                {
                    name : "Sourav Singh",
                    amount : +500,
                    tnxHash : "4ce18f49ba153a51bcda9bb80d7f978e3de6e81b5fc326f00465464530c052f4",
                    tnxDate : "April 22 2020",
                    tnxTime : "17:21:45"
                },
                {
                    name : "Smriti Das",
                    amount : -200,
                    tnxHash : "d5d27987d2a3dfc724e359870c6644b40e497bdc0589a033220fe15429d88599",
                    tnxDate : "April 20 2020",
                    tnxTime : "18:26:37"
                },
            ]
        }

        AsyncStorage.getItem("jwtToken")
        .then(token => {
            console.log("TOKES", token)
            fetch(global.ipAddr + global.getWalletBalance, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': token
                },
                body: JSON.stringify({
                    'channelName': 'mychannel',
                    'chaincodeId': 'papercontract',
                    'walletNo': '1'
                })
            })
            .then(response => response.json())
            .then(json => {
                console.log("JSSS", json)
                if(json.success == true){
                    let parsedData = JSON.parse(json.result)
                    this.setState({
                        transactionHistory: parsedData.transaction,
                        availableBalance: parsedData.balance
                    })
                    
                }
                else{
                    this.setState({
                        availableBalance: "NA"
                    })
                    alert("Cannot fetch transaction details. Please try again after sometime")
                }
                
            })
            .catch(error => {
                this.setState({
                    availableBalance: "NA"
                })
                alert("Cannot fetch balance details. Please try again after sometime")
            })
        })

        
        
    }

    addMoney = () => {
        // Actions.CategorySelection();
        alert("Money Added.")
    }

    payMoney = () => {
        // Actions.DeliverRation();
        alert("Money Paid.")
    }  

    render ( ) {
        
        return(
            <View style={{flex:1, backgroundColor: 'white'}}>
                <Header/>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop:"15%"}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/wb_govt.png')} />
                </View>
                <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingHorizontal:"9%"}}>
                    <Text style={TransactionHistoryStyle.balanceText}>Available Balance :  &#8377; {this.state.availableBalance} </Text>
                </View>
                <ScrollView style={{ marginTop:'2%'}}>
                    {this.state.transactionHistory.map((data, index) => {
                        return(
                            <View key={index}>
                                <View style={{flex:1, justifyContent: 'center', marginTop:"0%"}}>
                                    <TouchableOpacity onPress={this.payMoney} style={TransactionHistoryStyle.buttonStyle} style={{flexDirection:"row"}}>
                                        <Image style={{resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/userProfile.png')} />
                                        <View style={{flex:1, flexDirection:"row"}}>
                                            <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={TransactionHistoryStyle.buttonText}>Paid To : Sumit Maiti </Text>
                                            </View>
                                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-end', paddingRight: '10%'}}>
                                                <Text style={TransactionHistoryStyle.amount}> {data.amount} </Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                    <View style={{flex:1, flexDirection:"row"}}>
                                        <View style={{width:"11%"}}></View>
                                        <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                            <Text style={TransactionHistoryStyle.tnxDetails}>Date : {data.transationDateTime} </Text>
                                        </View>
                                        <View style={{flex: 1, justifyContent: 'center',  alignItems: 'flex-end',paddingRight: '10%'}}>
                                            <Text style={TransactionHistoryStyle.tnxDetails}>Txn Id : {data.transactionId} </Text>
                                        </View>
                                    </View>
                                    <View style={{flex:1, flexDirection:"row"}}>
                                        <View style={{width:"11%"}}></View>
                                        <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                            <Text style={TransactionHistoryStyle.tnxHashDetails}>Tnx Hash : 4ce18f49ba153a51bcda9bb80d7f978e3de6e81b5fc326f00465464530c052f4 </Text>
                                        </View>
                                    </View>
                                </View>
                                <View style={{flex:1, justifyContent: 'center', marginTop:"3%", borderBottomWidth:1.5,borderBottomColor: "#2C9E3F", marginHorizontal:"3%"}}>
                                    
                                </View>
                            </View>
                        )
                    })}
                </ScrollView>
                <Footer/>
            </View>
        )
    }
}