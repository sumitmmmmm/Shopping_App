import React from 'react';
import { Dimensions, Text, ScrollView ,View,Image,TouchableOpacity, AsyncStorage } from 'react-native';
import HeaderStyle from './headerStyle';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faHome, faBookOpen, faHandHolding, faBell, faUser } from '@fortawesome/free-solid-svg-icons';
// import TimePicker from 'react-native-simple-.time-picker';
import * as Permissions from "expo-permissions";
import { Actions } from 'react-native-router-flux';
import { text } from '@fortawesome/fontawesome-svg-core';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class Header extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            mobileNumber: ''
        }

        AsyncStorage.getItem("mobileNumber")
        .then(res => JSON.parse(res))
        .then(json => {
            this.setState({
                mobileNumber: json
            })
        })
    }

    // scheduleDelivery = () => {
    //     Actions.CategorySelection();
    // }

    // makeDelivery = () => {
    //     Actions.DeliverRation();
    // }  

    render ( ) {
        
        return(
            <View style={{backgroundColor: '#E8E8E8',paddingHorizontal:0.06*width}}>
                    <View style={HeaderStyle.imageStyle}>
                        <View style={{justifyContent: 'flex-start', flexDirection:"row"}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <FontAwesomeIcon icon={faUser} size={40} style={{color:"#337AFF"}}/>
                            </View>
                            <View style={{justifyContent: 'flex-start', alignItems: 'center', paddingHorizontal: height*0.03}}>
                                <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{alignSelf:"flex-end",fontSize:25, fontWeight: 'bold', textAlign: 'center'}}>
                                        Hi Mouazzam! 
                                    </Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'center'}}>
                                    <Text style={{alignSelf:"flex-start",fontSize:14, fontStyle: 'italic', textAlign: 'center'}}>
                                    (Mobile No. {this.state.mobileNumber})
                                </Text>
                                </View>
                            </View>
                        </View>
                        
                    </View>
            
            </View>
        )
    }
}