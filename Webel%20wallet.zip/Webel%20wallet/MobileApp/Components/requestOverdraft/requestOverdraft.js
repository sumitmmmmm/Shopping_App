import React from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, KeyboardAvoidingView,TouchableWithoutFeedback,Keyboard,Dimensions, ScrollView} from 'react-native';
import Modal from 'react-native-modal';
import { Actions } from 'react-native-router-flux';
// import MultiSelect from 'react-native-multiple-select';
import Footer from '../Footer/footer';
import Header from '../Header/header';
import global from '../global/globalConfiguration';
import { Dropdown } from 'react-native-material-dropdown';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCheckCircle, faHandHolding, faBell, faCheck } from '@fortawesome/free-solid-svg-icons';
import { Bubbles, DoubleBounce, Bars, Pulse } from 'react-native-loader';

export default class RequestOverDraft extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            displayModal: false,
            amount: '',
            backgroundColorSelectorFor100: 'green',
            backgroundColorSelectorFor200: 'green',
            backgroundColorSelectorFor250: 'green',
            backgroundColorSelectorFor500: 'green'
        }
    }

    width = Dimensions.get('window').width;
    height = Dimensions.get('window').height;

    handleAmount = (value) => {
        this.setState({
            amount: value
        })
    }

    amountSelector = (value) => {
        this.setState({
            amount: value
        })
        if(value == 100){
            this.setState({
                backgroundColorSelectorFor100: '#7FFF00',
                backgroundColorSelectorFor200: 'green', 
                backgroundColorSelectorFor250: 'green',
                backgroundColorSelectorFor500: 'green'
            })
        }
        else if(value == 200){
            this.setState({
                backgroundColorSelectorFor100: 'green',
                backgroundColorSelectorFor200: '#7FFF00', 
                backgroundColorSelectorFor250: 'green',
                backgroundColorSelectorFor500: 'green'
            })
        }
        else if(value == 250){
            this.setState({
                backgroundColorSelectorFor100: 'green',
                backgroundColorSelectorFor200: 'green', 
                backgroundColorSelectorFor250: '#7FFF00',
                backgroundColorSelectorFor500: 'green'
            })
        }
        else if(value == 500){
            this.setState({
                backgroundColorSelectorFor100: 'green',
                backgroundColorSelectorFor200: 'green', 
                backgroundColorSelectorFor250: 'green',
                backgroundColorSelectorFor500: '#7FFF00'
            })
        }
    }

    displayModal = () => {
        this.setState({
            displayModal: true
        })
    }

    modalContent = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#2C9E3F', borderRadius: 40, paddingBottom: this.height*0.05}}>
                
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({displayModal: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 18, fontWeight: 'bold', color: '#fff'}}>OverDraft Status Page</Text>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.04}}>
                    <FontAwesomeIcon icon={faCheckCircle} size={80} style={{color:"blue"}}/>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.04, marginHorizontal: this.width*0.05}}>
                    <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff', fontStyle: 'italic'}}>OverDraft Request successfully sent. We will verify the transaction and send you a notification.</Text>
                </View>
            </View>
        )
    }


    render(){
        return(
            <KeyboardAvoidingView style={{flex: 1}}>
               
                <Header/>

                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <View style={{flex:1}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center', marginTop: '3%'}}>
                                <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../assets/wb_govt.png')} />
                            </View>
                        </View>

                        <View style={{paddingVertical: '10%', borderRadius: 20, borderWidth: 5, borderColor: 'black', marginHorizontal: '2%'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontWeight: 'bold', fontSize: 22}}>Request Overdraft Page</Text>
                            </View>
                            <View style={{}}>
                                <View style={{ flexDirection: 'row', marginTop: this.height*0.04}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 16, fontWeight: 'bold'}}>Request Amount</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                    <TextInput
                                        style={{borderColor: 'black', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '80%', height: this.height*0.06}}
                                        placeholder='Enter Amount in Rs.'
                                        value={this.state.amount}
                                        onChangeText={this.handleAmount}
                                        keyboardType="number-pad"
                                    />
                                    </View>
                                </View>
                                <View style={{marginLeft: this.height*0.04}}>
                                    <Text style={{fontSize: 12, fontStyle: 'italic'}}>*Request amount limit: &#8377; 500</Text>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.04}}>
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>Fast Select Amount (in &#8377;)</Text>
                                </View>
                                <View style={{marginTop: this.height*0.02, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                                    
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <TouchableOpacity 
                                        style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.06, width: this.height*0.06, borderColor: '#006400', borderWidth: 3, borderRadius: this.height*0.03, backgroundColor: this.state.backgroundColorSelectorFor100}}
                                        onPress={() => this.amountSelector(100)}>
                                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>100</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <TouchableOpacity 
                                        style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.06, width: this.height*0.06,  borderColor: '#006400', borderWidth: 3, borderRadius: this.height*0.03, backgroundColor: this.state.backgroundColorSelectorFor200}}
                                        onPress={() => this.amountSelector(200)}>
                                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>200</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <TouchableOpacity 
                                        style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.06, width: this.height*0.06,  borderColor: '#006400', borderWidth: 3, borderRadius: this.height*0.03, backgroundColor: this.state.backgroundColorSelectorFor250}}
                                        onPress={() => this.amountSelector(250)}>
                                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>250</Text>
                                        </TouchableOpacity>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <TouchableOpacity 
                                        style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.06, width: this.height*0.06,  borderColor: '#006400', borderWidth: 3, borderRadius: this.height*0.03, backgroundColor: this.state.backgroundColorSelectorFor500}}
                                        onPress={() => this.amountSelector(500)}>
                                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>500</Text>
                                        </TouchableOpacity>
                                    </View>
                        
                                </View>

                                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '6%'}}>
                                    <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#2C9E3F'}} onPress={this.displayModal}>
                                        <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#fff'}}>Submit</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    </View>
                </TouchableWithoutFeedback>
                <Footer />

                <Modal
                    isVisible={this.state.displayModal == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalContent()}
                </Modal>

                </KeyboardAvoidingView>
        )
    }
}