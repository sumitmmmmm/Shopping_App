import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, KeyboardAvoidingView,TouchableWithoutFeedback,Keyboard,TouchableOpacity, Image, AsyncStorage, Dimensions} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
import Footer from '../Footer/footer';
import Header from '../Header/header';
import { ScrollView } from 'react-native-gesture-handler';

export default class SellerSeachForBuyer extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displayModal: false,
            buyerMobile: '',
            amount: '',
            loginValues: [
                {
                    id: '9090909090',
                    role: 'buyer',
                    name: 'Mayank Shrivastava',
                    mail: 'mayank@gmail.com',
                    address: 'Flat No-A21, Olive Apartments, Kolkata',
                },
                {
                    id: '6565656565',
                    role: 'buyer',
                    name: 'Jagat Lal',
                    mail: 'jagat@gmail.com',
                    address: 'Flat No-A21, Olive Apartments, Kolkata'
                },
                {
                    id: '8787878787',
                    role: 'buyer',
                    name: 'Laltu Das',
                    mail: 'laltu@gmail.com',
                    address: 'Flat No-A21, Olive Apartments, Kolkata'
                },
                {
                    id: '5454545454',
                    role: 'buyer',
                    name: 'Ram Puri',
                    mail: 'ram@gmail.com',
                    address: 'Flat No-A21, Olive Apartments, Kolkata'
                }
            ],
            selectedBuyer: {},
            showSelectedBuyer: false,
            comments: '',
            notificationStatus: false
        }

        AsyncStorage.getItem('login')
        .then(text => {return JSON.parse(text)})
        .then(value => {

            this.setState({
                loginID: value.id
            })
        })
    }

    handleAmount = (value) => {
        this.setState({
            amount: value
        })
    }
    
    handleComments = (value) => {
        this.setState({
            comments: value
        })
    }

    handleBuyerMobile = (value) => {
        this.setState({
            buyerMobile: value
        })
    }

    searchBuyer = () => {
        this.state.loginValues.map((value, index) => {
            if(this.state.buyerMobile == value.id){
                this.setState({
                    selectedBuyer: value,
                    showSelectedBuyer: true
                })
            }
        })
    }

    sendNotificationStatus = () => {
        this.setState({
            displayModal: true
        })
    }

    sendNotificationModal = () => {
        return(
            <View style={{justifyContent:"center", backgroundColor: '#003399', borderRadius: 40}}>
                <View style={{alignItems: 'flex-end', marginRight: '5%', marginTop:"2%"}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} 
                                    onPress={() => {this.setState({displayModal: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.02}}>
                    <Text style={{fontSize: 18, fontWeight: 'bold', color: '#fff'}}>Selected Buyer Details</Text>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.02, marginRight: this.width*0.02}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Name</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                            <Text style={{fontSize: 14, color: '#fff'}}>{this.state.selectedBuyer.name}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Contact</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                            <Text style={{fontSize: 14, color: '#fff'}}>{this.state.selectedBuyer.id}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Email</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                            <Text style={{fontSize: 14, color: '#fff'}}>{this.state.selectedBuyer.mail}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Address</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                            <Text style={{fontSize: 14, color: '#fff'}}>{this.state.selectedBuyer.address}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Amount(in Rs.)</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', borderRadius:10, borderWidth: 1, width: '100%', height: this.height*0.05, textAlign: 'center', color: 'black'}}
                            placeholder='Enter amount (in Rs.)'
                            placeholderTextColor="grey"
                            value={this.state.amount}
                            onChangeText={this.handleAmount}
                            
                        />
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginTop: this.height*0.02}}>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.1}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold', color: '#fff'}}>Comments</Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', borderRadius:10, borderWidth: 1, width: '100%', height: this.height*0.05, textAlign: 'center', color: 'black'}}
                            placeholder='Additional info, if any'
                            placeholderTextColor="grey"
                            value={this.state.comments}
                            onChangeText={this.handleComments}
                            
                        />
                        </View>
                    </View>
                    {this.state.notificationStatus == false ? 
                        <View style={{justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.008, marginTop: this.height*0.02}}>
                            <Text style={{color: '#fff', fontSize: 10, fontStyle: 'italic'}}>*The above buyer would be sent a notification for available items.</Text>
                        </View>:null
                
                    }
                    
                    {this.state.notificationStatus == false ? 
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%', marginTop: this.height*0.03}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#fff'}} onPress={this.sendNotification}>
                                <Text style={{color: '#003399', textAlign:"center",fontWeight: 'bold', fontSize: 15}}>Send Notification</Text>
                            </TouchableOpacity>
                        </View>:null
                
                    }

                    {this.state.notificationStatus == true ?
                    
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%', marginTop: this.height*0.03}}>
                        <Image style={{resizeMode: 'contain', width: 80, height: 80}}source={require('../../assets/registered_successful_tick.png')} />
                            <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.02}}>
                                <Text style={{color: '#fff', fontSize: 12}}>Notification sent to Buyer</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%', marginTop: this.height*0.03}}>
                                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#fff'}} onPress={() => {this.setState({displayModal: false})}}>
                                    <Text style={{color: '#003399', textAlign:"center",fontWeight: 'bold', fontSize: 15}}>Close</Text>
                                </TouchableOpacity>
                            </View>
                    </View>:null
                    }
                    
                </View>
            </View>
        )
    }

    sendNotification = () => {
        let selectedBuyerDetails = {
            sellerID: this.state.loginID,
            sellerName: 'Raja Kumar',
            sellerShopName: 'Raja General Stores',
            sellerShopAddress: 'Shop No-C/12, Tilak Road, opp. Central Mall, Kolkata',
            id: this.state.selectedBuyer.id,
            amount: this.state.amount,
            comments: this.state.comments,
            pickup: 'The customer would be picking up the items at 5:00 P.M on 30th June, 2020'
        }
        AsyncStorage.setItem("selectedBuyerDetails", JSON.stringify(selectedBuyerDetails))
        .then(value => {
            this.setState({
                notificationStatus: true
            })
        })

        
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    render(){
        return(
            <KeyboardAvoidingView style={{flex:1, backgroundColor: 'white'}}>
                
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <View style={{flex:1, marginTop: this.height*0.04}}>
                    
                        <View style={{ justifyContent: 'center', alignItems: 'center', paddingVertical: '10%'}}>
                            <Image style={{ resizeMode: 'contain',width: 80, height: 80}} source={require('../../assets/wb_govt.png')} />
                        </View>
                        <ScrollView>
                        <View style={{borderWidth: 2, borderColor: 'black', borderRadius: 20, paddingVertical: this.height*0.04, marginHorizontal: this.width*0.005}}>
                            <View style={{justifyContent: 'center', alignItems: 'center', marginBottom: this.height*0.04}}>
                                <Text style={{fontSize: 20 ,fontWeight: 'bold'}}>Dashboard</Text>
                            </View>

                            <View style={{justifyContent: 'center', alignItems: 'center', marginHorizontal: this.width*0.02}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Following customers would be receiving their items at the specified time.</Text>
                            </View>

                            <View style={{ marginTop: this.height*0.02, marginHorizontal: this.width*0.02}}>
                                <View style={{ flexDirection: 'row', backgroundColor: 'green', paddingVertical: this.height*0.01, borderTopRightRadius: 10, borderTopLeftRadius: 10}}>
                                    <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 12.5, fontWeight: 'bold', color: '#fff'}}>Name</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 12.5, fontWeight: 'bold', color: '#fff'}}>Contact</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 12.5, fontWeight: 'bold', color: '#fff'}}>Allocated Time Slot</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Ravi Shankar</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>9012301100</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>11:00 - 11:30 A.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Ram Das</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>8971010121</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>12:00 - 12:30 P.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Rajesh Pal</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>6012098111</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>1:00 - 1:30 P.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Shib Shankar</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>8091095611</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>1:30 - 2:00 P.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Peeyush Jena</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>9065102311</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>3:00 - 3:30 P.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>

                                <View style={{flexDirection: 'row', backgroundColor: '#90EE90', paddingVertical: this.height*0.01, borderBottomLeftRadius: 10, borderBottomRightRadius: 10}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', marginLeft: this.width*0.02}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Afzal Rahim</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>8651090911</Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>5:00 - 5:30 P.M</Text>
                                        <Text style={{fontSize: 11, fontWeight: 'bold'}}>Wed, Jul 8</Text>
                                    </View>
                                </View>
                            </View>
                            
                            {this.state.showSelectedBuyer == true ? 
                                <View style={{marginTop: this.height*0.03}}>
                                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 18, fontWeight: 'bold'}}>Buyer Profile</Text>
                                    </View>
                                    <View style={{justifyContent: 'center', alignItems: 'center', marginTop: this.height*0.03}}>
                                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginHorizontal: this.width*0.025}}>
                                            <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Name</Text>
                                            </View>
                                            <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 15}}>{this.state.selectedBuyer.name}</Text>
                                            </View>
                                        </View>

                                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginHorizontal: this.width*0.025, marginTop: this.height*0.02}}>
                                            <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Contact Number</Text>
                                            </View>
                                            <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 15}}>{this.state.selectedBuyer.id}</Text>
                                            </View>
                                        </View>

                                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginHorizontal: this.width*0.025, marginTop: this.height*0.02}}>
                                            <View style={{flex: 2, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Email</Text>
                                            </View>
                                            <View style={{flex: 3, justifyContent: 'center', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 15}}>{this.state.selectedBuyer.mail}</Text>
                                            </View>
                                        </View>

                                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginHorizontal: this.width*0.025, marginTop: this.height*0.02}}>
                                            <View style={{flex: 2, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Address</Text>
                                            </View>
                                            <View style={{flex: 3, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                                <Text style={{fontSize: 15}}>{this.state.selectedBuyer.address}</Text>
                                            </View>
                                        </View>
                                    </View>
                                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%', marginTop: this.height*0.03}}>
                                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'green'}} onPress={this.sendNotificationStatus}>
                                            <Text style={{color: '#fff', textAlign:"center",fontWeight: 'bold', fontSize: 15}}>Send Notification to Buyer</Text>
                                        </TouchableOpacity>
                                    </View>
                            </View>: null    
                            }
                        </View>
                        </ScrollView>
                    </View>
                </TouchableWithoutFeedback>
                <Modal
                    isVisible={this.state.displayModal == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.sendNotificationModal()}
                </Modal>
                <Footer/>
            </KeyboardAvoidingView>
        )
    }
}