import React from 'react';
import { StyleSheet,Dimensions,TextInput, Text, ScrollView ,View,Image,TouchableOpacity,Animated,AsyncStorage,TouchableWithoutFeedback,KeyboardAvoidingView,Keyboard,Platform,StatusBar } from 'react-native';
import MenuPageStyle from '../MenuPage/menuPageStyle';
import { Actions } from 'react-native-router-flux';
import Modal from 'react-native-modal';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faUser, faBars, faCaretDown, faBell, faMapPin, faPhoneAlt, faMapSigns } from '@fortawesome/free-solid-svg-icons';
import { Dropdown } from 'react-native-material-dropdown';
// import MultiSelect from 'react-native-multiple-select';
import Footer from '../Footer/footer';
import Header from '../Header/header';
import HeaderStyle from '../Header/headerStyle';
import * as ScheduleTimeData from '../staticData/scheduleTime.json';
import registerSellerStyle from '../Registeration/registerSellerStyle';

import MapView from 'react-native-maps';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export default class SearchResults extends React.Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    renderMap = () => {
        Actions.Map()
    }

    
    onRegionChange(region) {
        this.setState({ region });
      }

      sendNotification = (shopName, shopAddress) => {
        let notif = {
            name: 'Raj Kumar',
            id: '9090909090',
            shopName: shopName,
            shopAddress: shopAddress,
            comments: 'The total amount is Rs. 260 for the ordered items.',
            timing: 'Please visit the above shop at the allocated time slot 4P.M - 4:30P.M on 29th June, 2020',
            pickup: 'The customer would be picking up the items at 5:00 P.M on 30th June, 2020'
        }

        AsyncStorage.setItem("selectedBuyerDetails", JSON.stringify(notif))
        .then(value => {
            alert('Notification sent to seller.')
        })
      }

    render(){
        return(
            <KeyboardAvoidingView style={{flex:1}}>
                
            {/* <View style={{backgroundColor: '#fff',paddingHorizontal:0.06*width}}>
                    <View style={HeaderStyle.imageStyle}>
                        <View style={{flexDirection:"row",justifyContent:"space-between"}}>
                            <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <FontAwesomeIcon icon={faBars} size={20} style={{color:"#003399"}}/>
                            </View>
                            <View style={{justifyContent: 'center',alignItems: 'flex-start', paddingRight: height*0.22}}>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <TouchableOpacity onPress={this.chooseLanguage}>
                                        <View style={{flexDirection:"row"}}>
                                            <View>
                                            <Text style={{alignSelf:"flex-start",fontSize:20,color:"#003399", fontWeight: 'bold', textAlign: 'left'}}>
                                            {this.state.language} 
                                            </Text>
                                            </View>
                                            <View style={{justifyContent:"center",padding:"2%"}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={20} style={{color:"#003399"}}/>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            <View style={{justifyContent: 'flex-end', alignItems: 'flex-end'}}>
                                <FontAwesomeIcon icon={faBell} size={18} style={{color:"#003399"}}/>
                            </View>
                        </View>
                        
                    </View>
                </View> */}

                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <View style={{flex: 1, marginTop: this.height*0.04}}>
                    
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>0.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Raj General Store</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.22, near Tank No. 8, CA Block, NewTown</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Raj General Store', 'Shop No.22, near Tank No. 8, CA Block, NewTown')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                            </View>
                            

                        </View>

                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>2.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Shiva SuperMarket</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>5th Floor, Axis Mall, NewTown, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Shiva SuperMarket', '5th Floor, Axis Mall, NewTown, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                            </View>

                        </View>
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>6.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Maiti Groceries</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.44/C, opp. Charnock Hospital, Chinar Park, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Maiti Groceries', 'Shop No.44/C, opp. Charnock Hospital, Chinar Park, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                            </View>

                        </View>
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>7.0 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Chatterjee & Sons</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.1/B, near Airport Gate No. 1, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Chatterjee & Sons', 'Shop No.1/B, near Airport Gate No. 1, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                            </View>

                        </View>



                    </View>
                 
                </TouchableWithoutFeedback>
              
                <Footer/>
                    </KeyboardAvoidingView>
            
        )
    }
}