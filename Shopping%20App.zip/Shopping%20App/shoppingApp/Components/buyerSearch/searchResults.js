import React from 'react';
import { StyleSheet,Dimensions,TextInput, Text, ScrollView ,CheckBox, View,Image,TouchableOpacity,Animated,AsyncStorage,TouchableWithoutFeedback,KeyboardAvoidingView,Keyboard,Platform,StatusBar } from 'react-native';
import MenuPageStyle from '../MenuPage/menuPageStyle';
import { Actions } from 'react-native-router-flux';
import Modal from 'react-native-modal';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faUser, faBars, faShoppingBasket, faCaretDown, faCaretUp, faMapPin, faPhoneAlt, faMapSigns } from '@fortawesome/free-solid-svg-icons';
import { Dropdown } from 'react-native-material-dropdown';
// import MultiSelect from 'react-native-multiple-select';
import Footer from '../Footer/footer';
import Header from '../Header/header';
import HeaderStyle from '../Header/headerStyle';
import * as ScheduleTimeData from '../staticData/scheduleTime.json';
import registerSellerStyle from '../Registeration/registerSellerStyle';

import MapView from 'react-native-maps';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export default class SearchResults extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            showAvailableItems1: false,
            showAvailableItems2: false,
            showAvailableItems3: false,
            showAvailableItems4: false,
            availableItems: [
                {
                    name: 'Rice',
                    selected: false,
                    background: 'green'
                },
                {
                    name: 'Wheat',
                    selected: false,
                    background: 'green'
                },
                {
                    name: 'Pulses',
                    selected: false,
                    background: 'green'
                },
                {
                    name: 'Cooking Oil',
                    selected: false,
                    background: 'green'
                }
            ],
            selectedItems: [false, false, false, false]
        }
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    renderMap = () => {
        Actions.Map()
    }

    
    onRegionChange(region) {
        this.setState({ region });
    }

    showAvailableItems1 = () => {
        this.setState({
            showAvailableItems1: !this.state.showAvailableItems1
        })
    }

    showAvailableItems2 = () => {
        this.setState({
            showAvailableItems2: !this.state.showAvailableItems2
        })
    }

    showAvailableItems3 = () => {
        this.setState({
            showAvailableItems3: !this.state.showAvailableItems3
        })
    }

    showAvailableItems4 = () => {
        this.setState({
            showAvailableItems4: !this.state.showAvailableItems4
        })
    }

    setSelectedItems = (index) => {
        this.state.availableItems[index].selected = !this.state.availableItems[index].selected;
        if(this.state.availableItems[index].background == 'green'){
            this.state.availableItems[index].background = 'blue'
        }
        else{
            this.state.availableItems[index].background = 'green'
        }
        this.forceUpdate();
    }

      sendNotification = (shopName, shopAddress) => {
        let notif = {
            name: 'Raj Kumar',
            id: '9090909090',
            shopName: shopName,
            shopAddress: shopAddress,
            comments: 'The total amount is Rs. 260 for the ordered items.',
            timing: 'Please visit the above shop at the allocated time slot 4P.M - 4:30P.M on 29th June, 2020',
            pickup: 'The customer would be picking up the items at 5:00 P.M on 30th June, 2020'
        }

        AsyncStorage.setItem("selectedBuyerDetails", JSON.stringify(notif))
        .then(value => {
            alert('Notification sent to seller.')
        })
      }

    render(){
        return(
            <KeyboardAvoidingView style={{flex:1}}>
                
         <Header />

                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                    <View style={{flex: 1, marginTop: this.height*0.04}}>
                    
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>0.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Raj General Store</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.22, near Tank No. 8, CA Block, NewTown</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Raj General Store', 'Shop No.22, near Tank No. 8, CA Block, NewTown')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                   
                                </View>

                                <View style={{paddingTop: '3%'}}>
                                    <TouchableOpacity style={{flexDirection: "row"}} onPress={this.showAvailableItems1}>
                                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faShoppingBasket} size={15} style={{color:"green"}}/>
                                        </View>
                                        <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingLeft: '2%'}}>
                                            <Text style={{fontSize: 12, textAlign: 'center'}}>Select from available Items</Text>
                                        </View>
                                        {this.state.showAvailableItems1 == true ? 
                                        
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faCaretUp} size={12} style={{color:"green"}}/>
                                            </View>:
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={12} style={{color:"green"}}/>
                                        </View>
                                    }
                                    </TouchableOpacity>
                                    {this.state.showAvailableItems1 == true ? 
                                    
                                        <View >
                                            {this.state.availableItems.map((value, index) => {
                                                return(
                                                    <TouchableOpacity key={index} 
                                                        style={{flexDirection: 'row', marginLeft: this.width*0.05, backgroundColor: value.background, marginRight: this.width*0.35, marginTop: this.height*0.01, padding: '2%', borderBottomEndRadius: 10, borderTopLeftRadius: 10}}
                                                        onPress={() => this.setSelectedItems(index)}    >
                                                        <Text style={{fontSize: 11, fontStyle: 'italic', color: '#fff'}}>{index+1}. {value.name}</Text>
                                                        {/* <CheckBox
                                                            value={this.state.selectedItems[index]}
                                                            // onChange=
                                                            onChange={() => this.setSelection(index)}
                                                            style={{height: this.height*0.01}}
                                                            /> */}
                                                    </TouchableOpacity>
                                                )
                                            })}
                                        </View> : null

                                    }
                                </View>

                            </View>
                            

                        </View>

                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>2.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Shiva SuperMarket</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>5th Floor, Axis Mall, NewTown, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Shiva SuperMarket', '5th Floor, Axis Mall, NewTown, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                                <View style={{paddingTop: '3%'}}>
                                    <TouchableOpacity style={{flexDirection: "row"}} onPress={this.showAvailableItems2}>
                                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faShoppingBasket} size={15} style={{color:"green"}}/>
                                        </View>
                                        <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingLeft: '2%'}}>
                                            <Text style={{fontSize: 12, textAlign: 'center'}}>Show Available Items</Text>
                                        </View>
                                        {this.state.showAvailableItems2 == true ? 
                                        
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faCaretUp} size={12} style={{color:"green"}}/>
                                            </View>:
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={12} style={{color:"green"}}/>
                                        </View>
                                    }
                                    </TouchableOpacity>
                                    {this.state.showAvailableItems2 == true ? 
                                    
                                        <View >
                                            {this.state.availableItems.map((value, index) => {
                                                return(
                                                    <View key={index} style={{marginLeft: this.width*0.05}}>
                                                        <Text style={{fontSize: 11, fontStyle: 'italic'}}>{index+1}. {value}</Text>
                                                    </View>
                                                )
                                            })}
                                        </View> : null

                                    }
                                </View>

                            </View>

                        </View>
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>6.2 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Maiti Groceries</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.44/C, opp. Charnock Hospital, Chinar Park, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Maiti Groceries', 'Shop No.44/C, opp. Charnock Hospital, Chinar Park, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                                <View style={{paddingTop: '3%'}}>
                                    <TouchableOpacity style={{flexDirection: "row"}} onPress={this.showAvailableItems3}>
                                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faShoppingBasket} size={15} style={{color:"green"}}/>
                                        </View>
                                        <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingLeft: '2%'}}>
                                            <Text style={{fontSize: 12, textAlign: 'center'}}>Show Available Items</Text>
                                        </View>
                                        {this.state.showAvailableItems3 == true ? 
                                        
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faCaretUp} size={12} style={{color:"green"}}/>
                                            </View>:
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={12} style={{color:"green"}}/>
                                        </View>
                                    }
                                    </TouchableOpacity>
                                    {this.state.showAvailableItems3 == true ? 
                                    
                                        <View >
                                            {this.state.availableItems.map((value, index) => {
                                                return(
                                                    <View key={index} style={{marginLeft: this.width*0.05}}>
                                                        <Text style={{fontSize: 11, fontStyle: 'italic'}}>{index+1}. {value}</Text>
                                                    </View>
                                                )
                                            })}
                                        </View> : null

                                    }
                                </View>
                            </View>

                        </View>
                        <View style={{flexDirection: 'row', paddingHorizontal: '3%', paddingVertical: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <View style={{borderRadius: 2, borderColor: 'black', borderWidth: 3}}>
                                    <TouchableOpacity style={{padding: '10%'}}>
                                        <FontAwesomeIcon icon={faMapPin} size={30} style={{color:"red"}}/>
                                    </TouchableOpacity>
                                </View>
                                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '2%', marginLeft: '5%'}}>
                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>7.0 KM</Text>
                                </View>
                                
                            </View>
                            <View style={{flex: 5}}>
                                
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 16}}>Chatterjee & Sons</Text>
                                </View>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <Text style={{fontStyle: 'italic', fontSize: 14}}>Shop No.1/B, near Airport Gate No. 1, Kolkata</Text>
                                </View>
                                <View style={{flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', paddingTop: '3%'}}>
                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={() => this.sendNotification('Chatterjee & Sons', 'Shop No.1/B, near Airport Gate No. 1, Kolkata')}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faPhoneAlt} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center', paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>Call Now</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                    <View style={{flex: 1}}>
                                        <TouchableOpacity style={{flexDirection: "row"}} onPress={this.renderMap}>
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faMapSigns} size={15} style={{color:"green"}}/>
                                            </View>
                                            <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingHorizontal: '2%'}}>
                                                <Text style={{fontSize: 12, textAlign: 'center'}}>View on Map</Text>
                                            </View>
                                        </TouchableOpacity>
                                    </View>

                                   
                                </View>

                                <View style={{paddingTop: '3%'}}>
                                    <TouchableOpacity style={{flexDirection: "row"}} onPress={this.showAvailableItems4}>
                                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faShoppingBasket} size={15} style={{color:"green"}}/>
                                        </View>
                                        <View style={{justifyContent: 'center', alignItems: 'center', textAlign: 'center',  paddingLeft: '2%'}}>
                                            <Text style={{fontSize: 12, textAlign: 'center'}}>Show Available Items</Text>
                                        </View>
                                        {this.state.showAvailableItems4 == true ? 
                                        
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                                <FontAwesomeIcon icon={faCaretUp} size={12} style={{color:"green"}}/>
                                            </View>:
                                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={12} style={{color:"green"}}/>
                                        </View>
                                    }
                                    </TouchableOpacity>
                                    {this.state.showAvailableItems4 == true ? 
                                    
                                        <View >
                                            {this.state.availableItems.map((value, index) => {
                                                return(
                                                    <View key={index} style={{marginLeft: this.width*0.05}}>
                                                        <Text style={{fontSize: 11, fontStyle: 'italic'}}>{index+1}. {value}</Text>
                                                    </View>
                                                )
                                            })}
                                        </View> : null

                                    }
                                </View>

                            </View>

                        </View>



                    </View>
                 
                </TouchableWithoutFeedback>
              
                <Footer/>
                    </KeyboardAvoidingView>
            
        )
    }
}