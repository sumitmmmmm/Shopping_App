import React from 'react';
import { Dimensions, Text,  View ,TouchableOpacity} from 'react-native';
import HeaderStyle from './headerStyle';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faUser, faBars, faCaretDown, faBell } from '@fortawesome/free-solid-svg-icons';
// import TimePicker from 'react-native-simple-.time-picker';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class HeaderForCategory extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            // name: props.language
        }
    }

    render ( ) {
        
        return(
            <View style={{backgroundColor: '#fff',paddingHorizontal:0.06*width}}>
                    <View style={HeaderStyle.imageStyle}>
                        <View style={{flexDirection:"row",justifyContent:"space-between"}}>
                            <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <FontAwesomeIcon icon={faBars} size={20} style={{color:"#003399"}}/>
                            </View>
                            <View style={{justifyContent: 'center',alignItems: 'flex-start', paddingRight: height*0.22}}>
                                <View style={{justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                    <TouchableOpacity onPress={this.props.chooseModal}>
                                        <View style={{flexDirection:"row"}}>
                                            <View>
                                            <Text style={{alignSelf:"flex-start",fontSize:20,color:"#003399", fontWeight: 'bold', textAlign: 'left'}}>
                                                English
                                            </Text>
                                            </View>
                                            <View style={{justifyContent:"center",padding:"2%"}}>
                                            <FontAwesomeIcon icon={faCaretDown} size={20} style={{color:"#003399"}}/>
                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>
                            <View style={{justifyContent: 'flex-end', alignItems: 'flex-end'}}>
                                <FontAwesomeIcon icon={faBell} size={18} style={{color:"#003399"}}/>
                            </View>
                        </View>
                        
                    </View>
            
            </View>
        )
    }
}