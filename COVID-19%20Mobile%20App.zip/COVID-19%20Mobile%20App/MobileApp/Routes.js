import { Router, Scene } from 'react-native-router-flux'
import React from 'react'
import LoginScreen from './app/Components/Login/login';
import CitizenListScreen from './app/Components/Government/citizenList/citizenList';
import DeliverRation from './app/Components/Government/deliverRation/deliverRation'
import LandingPage from './app/Components/Government/LandingPage/landingPage'
import ScheduleRationDeliveryScreen from './app/Components/Government/ScheduleRationDelivery/scheduleRationDelivery'
import RescheduleDelivery from './app/Components/Government/RescheduleDelivery/rescheduleDelivery';
import CategorySelection from './app/Components/Government/CategorySelection/categorySelection';
import MenuPageScreen from './app/Components/MenuPage/menuPage';
import RequestStatus from './app/Components/Government/RequestStatus/RequestStatus';
const Routes = () => (
    <Router>
       <Scene key = "root">
          <Scene key = "MenuPageScreen"  component = {MenuPageScreen}  hideNavBar="true" />
          <Scene key = "LoginScreen" component ={LoginScreen} hideNavBar="true"/>
          <Scene key = "LandingPage" component ={LandingPage} initial={true} hideNavBar="true"/>
          <Scene key = "CitizenListScreen" component ={CitizenListScreen} hideNavBar="true" />
          <Scene key = "DeliverRation" component ={DeliverRation}  hideNavBar="true" />
          <Scene key = "CategorySelection" component ={CategorySelection} hideNavBar="true" />
          <Scene key = "RequestStatus" component ={RequestStatus} hideNavBar="true" />
          <Scene key = "ScheduleRationDeliveryScreen"  component = {ScheduleRationDeliveryScreen} hideNavBar="true" />
          <Scene key = "RescheduleDelivery"  component = {RescheduleDelivery} hideNavBar="true" />
       </Scene>
    </Router>
 )
 export default Routes