import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
import Map from '../Map/map'

export default class GovernmentScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            resourceHistory: [],
            riceQuantityOnDisplay: '',
            cashOnDisplay: '',
            wheatQuantityOnDisplay: '',
            barleyQuantityOnDisplay: '',
            pulsesQuantityOnDisplay: '',
            mobileNumber: '',
            role: '',
            dateOnDisplay: '',
            locationOnDisplay: ''
        }

        AsyncStorage.getItem('latestResource')
        .then(res => JSON.parse(res))
        .then(latestResource => {
            this.setState({
                riceQuantityOnDisplay: latestResource.rice,
                wheatQuantityOnDisplay: latestResource.wheat,
                barleyQuantityOnDisplay: latestResource.barley,
                pulsesQuantityOnDisplay: latestResource.pulses,
                cashOnDisplay: latestResource.cash,
                dateOnDisplay: latestResource.date,
                locationOnDisplay: latestResource.location
            })
        })

        AsyncStorage.getItem('sentResources')
        .then(res => JSON.parse(res))
        .then(resources => {
            console.log("RESERS", resources)
            resources.map((value, index) => {
                this.setState(prevState => ({
                    resourceHistory: [...prevState.resourceHistory, value]
                }))
            })
        })

        AsyncStorage.getItem('loginDetails')
        .then(res => JSON.parse(res))
        .then(loginDetails => {
            this.setState({
                mobileNumber: loginDetails.mobile,
                role: loginDetails.selectedRole
            })
        })
    }

    renderResource = (value, index) => {
        console.log("My REnderere", value)
        this.setState({
                riceQuantityOnDisplay: value.rice,
                wheatQuantityOnDisplay: value.wheat,
                barleyQuantityOnDisplay: value.barley,
                pulsesQuantityOnDisplay: value.pulses,
                cashOnDisplay: value.cash,
                dateOnDisplay: value.date,
                locationOnDisplay: value.location
        })
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    logOut = () => {
        Actions.LoginScreen();
    }

    resourceDisplayer = (value, index) => {
        value.rice = parseInt(value.rice)
        value.wheat = parseInt(value.wheat)
        value.barley = parseInt(value.barley)
        value.pulses = parseInt(value.pulses)
        return(
        <View key={index} style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
            <TouchableOpacity style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#DCDCDC', borderRadius: 20}} onPress={() => this.renderResource(value, index)}>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontWeight: 'bold', fontSize: 12}}>{index+1}</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontWeight: 'bold', fontSize: 12}}>{value.rice + value.wheat + value.barley + value.pulses}</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontWeight: 'bold', fontSize: 12}}>{value.cash}</Text>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontWeight: 'bold', fontSize: 12}}>{value.date}</Text>
                </View>
            </TouchableOpacity>

            
        </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center', marginTop: '5%'}}>
                 <View style={{flex: 2, flexDirection: 'row', alignItems: 'center'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingVertical: '3%', paddingHorizontal: '3%'}}>
                    
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>User ID: </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 10}}>{this.state.mobileNumber}</Text>
                            </View>
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>Role:  </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 10}}>{this.state.role}</Text>
                            </View>
                    
                        </View>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-end', paddingHorizontal: '3%'}}>
                    <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#DC143C'}} onPress={this.logOut}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>LogOut</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={{flex: 7, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFF8DC'}}>
                <ScrollView contentContainerStyle={{justifyContent: 'center', alignItems: 'center', width: this.width*0.95}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                        <Text style={{fontSize: 20, fontWeight: 'bold'}}>Resource Receipt</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingBottom: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Date</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.dateOnDisplay}</Text>
                            </View>
                        </View>
                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingBottom: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Location</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.locationOnDisplay}</Text>
                            </View>
                        </View>
                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingBottom: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Cash Transferred</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>Rs. {this.state.cashOnDisplay}</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingBottom: '5%'}}>
                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingBottom: '3%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Item</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Quantity(in kg)</Text>
                            </View>
                        </View>

                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{flex: 1,justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>Rice</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.riceQuantityOnDisplay}</Text>
                            </View>
                        </View>

                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>Wheat</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.wheatQuantityOnDisplay}</Text>
                            </View>
                        </View>

                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>Barley</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.barleyQuantityOnDisplay}</Text>
                            </View>
                        </View>

                        <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>Pulses</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold'}}>{this.state.pulsesQuantityOnDisplay}</Text>
                            </View>
                        </View>
                    </View>
                    </ScrollView>
                </View>

                <View style={{flex: 8, justifyContent: 'center', alignItems: 'center', backgroundColor: '#D4E6F1'}}>
                    <ScrollView contentContainerStyle={{justifyContent: 'center', alignItems: 'center', width: this.width*0.95}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', width: this.width}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingBottom: '8%'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold'}}>History of Resources Transferred</Text>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
                                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 14}}>Sl. No.</Text>
                                </View>
                                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 14}}>Total Qty.(kg)</Text>
                                </View>
                                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 14}}>Cash(Rs.)</Text>
                                </View>
                                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontWeight: 'bold', fontSize: 14}}>Date</Text>
                                </View>
                            </View>

                            
                        </View>
                        {this.state.resourceHistory.map((value, index) => {
                            return this.resourceDisplayer(value, index)
                        })}
                        </View>
                    </ScrollView>
                </View>

                <View style={{flex: 8, justifyContent: 'center', alignItems: 'center'}}>
                    <Map />
                </View>



            </View>
        )
    }
}