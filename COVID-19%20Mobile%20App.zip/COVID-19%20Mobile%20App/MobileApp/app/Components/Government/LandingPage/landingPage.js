import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView} from 'react-native';
import { Actions } from 'react-native-router-flux';
import MultiSelect from 'react-native-multiple-select';
import global from '../../staticData/globalConfigurationFile';
import { Bubbles, DoubleBounce, Bars, Pulse } from 'react-native-loader';
import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
import { JSHash, CONSTANTS } from "react-native-hash";
import Map from '../../Map/map'
import * as citizenList from '../../staticData/citizenList'
import DatePicker from 'react-native-datepicker'

export default class LandingPage extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            loaderForOTP: false,
            loader: false,
            xxxx: '',
            openModalForLogin: false,
            mobileNumber: '',
            openModalForRegister: false,
            licenseNumber: '',
            dob: '',
            hashedPassword: '',
            password: '',
            reEnterPassword: '',
            licenseNumberForLogin: '',
            passwordForLogin: '',
            generatedOTP: false,
            OTP: '',
            correctOTP: '',
            reEnterOTP: false
        }
        
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    handleOTP = (value) => {
        this.setState({
            OTP: value
        })
    }

    generateOTP = () => {

        JSHash(this.state.password, CONSTANTS.HashAlgorithms.keccak)
        .then(hash => this.setState({
            hashedPassword: hash
        }))
        .catch(e => {
            alert('Error logging in')
            console.log(e)});

        this.setState({
            loaderForOTP: true
        })
        var correctOTP = Math.floor(100000 + Math.random() * 900000); 
        
        this.setState({
            correctOTP: correctOTP
        })
        this.sendMessage(correctOTP);
    }

    sendMessage = (correctOTP) => {

            console.log("CORRECT",this.state.correctOTP)
            fetch( global.ipAddr + global.sendMessage, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    
                },
                body: JSON.stringify({
                    "Mobile": this.state.mobileNumber,
                    'Message': `${correctOTP} is the OTP to login in to your Ration and Relief distribution account. Please do not share it with anyone.`
                })
            })
            .then(response => response.json())
            .then(json => {
                this.setState({
                    generatedOTP: true,
                    loaderForOTP : false,
                })
            })
            .catch(error => {
                console.log(error)
                this.setState({
                    generatedOTP: true,
                    loaderForOTP : false,
                })
                // alert('Unable to send OTP, please try again after some time.')
            })
    }

    handleMobileNumber = (value) => {
        this.setState({
            mobileNumber: value
        })
    }

    handleLicenseNumber = (value) => {
        this.setState({
            licenseNumber: value
        })
    }

    handlePasswordForLogin = (value) => {
        this.setState({
            passwordForLogin: value
        })
    }

    handleLicenseNumberForLogin = (value) => {
        this.setState({
            licenseNumberForLogin: value
        })
    }

    handledob = (value) => {
        this.setState({
            dob: value
        })
    }

    login = () => {
        this.setState({
            openModalForLogin: false
        })
        Actions.MenuPageScreen()
    }

    submitOTP = () => {

        this.setState({
            loader: true,
            reEnterOTP: false
        })

        // if(this.state.OTP == this.state.correctOTP){
            
            fetch(global.ipAddr + global.getToken, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    Username: this.state.mobileNumber,
                    Password: this.state.hashedPassword
                })
            })
            .then(response => response.json())
            .then(jwtToken => {
                console.log(jwtToken)
                AsyncStorage.setItem("jwtToken", JSON.stringify(jwtToken.Token))
                this.setState({
                    loader: false,
                    openModalForRegister: false,
                    generatedOTP: false
                })

                fetch(global.ipAddr + global.ownerDetails + `?filter[where][MobileNo]=${this.state.mobileNumber}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': jwtToken.Token
                    },
                    
                })
                .then(response => response.json())
                .then(json => {
                    let ownerDetails = {
                        firstName: json[0].FirstName,
                        lastName: json[0].LastName,
                        licenseNo: json[0].LicenseNo,
                        mobileNumber: json[0].MobileNo,
                        shopName: json[0].ShopName,
                        subDivision: json[0].Subdivision,
                        block: json[0].Block,
                        dob: json[0].DOB,
                        district: json[0].District
                    }

                    AsyncStorage.setItem("OwnerDetails", JSON.stringify(ownerDetails))
                    .then(res => {
                        Actions.MenuPageScreen();
                    })
                })
                
            })
            .catch(error => alert("Error", error))


        // }
        // else{
        //     this.setState({
        //         reEnterOTP: true,
        //         loader: false
        //     })
        // }

       

       
    }

    modalForLogin = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.5}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({openModalForLogin: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 16, fontWeight: 'bold', color: '#fff'}}>Enter Login Credentials</Text>
                </View>
                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>License Number</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter License number'
                                value={this.state.licenseNumberForLogin}
                                onChangeText={this.handleLicenseNumberForLogin}
                                
                            />
                        </View>
                    </View>

                   

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Password</Text>
                        </View>
                        <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                            <TextInput
                                style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                                placeholder='Enter Password'
                                value={this.state.passwordForLogin}
                                onChangeText={this.handlePasswordForLogin}
                                secureTextEntry={true}
                            />
                        </View>
                    </View>

                   
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.login}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#003399'}}>Submit</Text>
                            </TouchableOpacity>
                        </View>
            </View>
        )
    }

    handlePassword = (value) => {
        this.setState({
            password: value
        })
    } 

    xxxx = (value) => {
        this.setState({
            xxxx: value
        })
    }

    handleReEnterPassword = (value) => {
        this.setState({
            reEnterPassword:  value
        })
    } 

    

    modalForRegister = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.7}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({openModalForRegister: false, generatedOTP: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
                    <Text style={{fontSize: 16, fontWeight: 'bold', color: '#fff'}}>Login Page</Text>
                </View>
                {this.state.generatedOTP == false ? 
                
                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>License Number</Text>
                    </View>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='Enter License number'
                            value={this.state.licenseNumber}
                            onChangeText={this.handleLicenseNumber}
                            
                        />
                    </View>
                </View>

                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>XX</Text>
                    </View>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                    <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='XXXX'
                            value={this.state.xxxx}
                            onChangeText={this.xxxx}
                            
                        />
                       
                    </View>
                </View>

                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Mobile No.</Text>
                    </View>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='Enter Mobile No.'
                            value={this.state.mobileNumber}
                            onChangeText={this.handleMobileNumber}
                            keyboardType="number-pad"
                        />
                    </View>
                </View>

                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Password</Text>
                    </View>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='Enter Password'
                            value={this.state.password}
                            onChangeText={this.handlePassword}
                            secureTextEntry={true}
                        />
                    </View>
                </View>

                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '1%', marginHorizontal: '3%'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: '2%'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Confirm Password</Text>
                    </View>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='Re-Enter Password'
                            value={this.state.reEnterPassword}
                            onChangeText={this.handleReEnterPassword}
                            secureTextEntry={true}
                        />
                    </View>
                </View>
            </View>
                    : null
                
                }
                
                {this.state.generatedOTP == false ? 
                
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.generateOTP}>
                    <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#003399'}}>Next</Text>
                </TouchableOpacity>
                {this.state.loaderForOTP == true ? 
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '1%'}}>
                            <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>Generating OTP. Please wait...</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Bars size={10} color= '#fff' />
                            </View>
                        </View>
                        : null
                    }
                </View>: null
                
                }

                {this.state.generatedOTP == true ? 
                <View style={{flex: 6, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Enter the OTP sent to {this.state.mobileNumber} complete registration</Text>
                    </View>
                    {this.state.reEnterOTP == true ? 
                     <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                        <Text style={{fontSize: 11, fontWeight: 'bold', color: '#fff'}}>Entered OTP is incorrect, Please try again.</Text>
                    </View>:null
                
                    }
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.05}}
                            placeholder='Enter OTP'
                            value={this.state.OTP}
                            onChangeText={this.handleOTP}
                            secureTextEntry={true}
                            keyboardType="number-pad"
                            maxLength={6}
                            minLength={6}
                        />
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={this.submitOTP}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#003399'}}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                    {this.state.loader == true ? 
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>Logging you in. Please wait...</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Bars size={10} color= '#fff' />
                            </View>
                        </View>
                        : null
                    }
                    
                    
                </View>: null
            
                }

            </View>
        )
    }

    openModalForLogin = () => {
        this.setState({
            openModalForLogin: true
        })
    }

    openModalForRegister = () => {
        this.setState({
            openModalForRegister: true
        })
    }

    render(){
        
        return(
            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                <Image style={{ position: 'absolute', opacity: 0.4, width: this.width, height: this.height}} source={require('../../../../assets/loginBG.jpeg')} />
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '10%'}}>
                    <Text style={{fontSize: 25, fontWeight: 'bold', textAlign: 'center'}}>Ration and Relief Articles Distribution</Text>
                </View>
                
                <View style={{justifyContent: 'center', alignItems: 'center'}}>
                    {/* <View style={{justifyContent: 'center', alignItems: 'flex-start', paddingVertical: '4%'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 10 ,fontStyle: 'italic', fontWeight: 'bold'}}>Existing User?</Text>
                        </View>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '15%', borderRadius: 10, backgroundColor: '#003399'}} onPress={() => this.openModalForLogin()}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Login</Text>
                        </TouchableOpacity>
                    </View> */}
                    <View style={{justifyContent: 'center', alignItems: 'flex-start', paddingVertical: '4%'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 10 ,fontStyle: 'italic', fontWeight: 'bold'}}>Existing User?</Text>
                        </View>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '13%', borderRadius: 10, backgroundColor: '#003399'}} onPress={() => this.openModalForRegister()}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Login</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={{alignItems: 'flex-end', paddingTop: '15%'}}>
                    <Image style={{ resizeMode: 'contain',width: 150, height: 150}} source={require('../../../../assets/wb_govt.png')} />
                </View>

                <Modal
                    isVisible={this.state.openModalForLogin == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalForLogin()}
                </Modal>

                <Modal
                    isVisible={this.state.openModalForRegister == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalForRegister()}
                </Modal>
            </View>
        )
    }
}