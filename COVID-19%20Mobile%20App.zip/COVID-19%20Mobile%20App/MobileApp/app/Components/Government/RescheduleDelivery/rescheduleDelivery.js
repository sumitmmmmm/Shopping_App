

import React from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView, KeyboardAvoidingView} from 'react-native';
import { Actions } from 'react-native-router-flux';
// import MultiSelect from 'react-native-multiple-select';
// import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
// import Map from '../../Map/map'
import ScheduleRationDeliveryStyle from '../ScheduleRationDelivery/scheduleRationDeliveryStyle';
import * as citizenList from '../../staticData/rescheduleCitizenList.json';
import Footer from '../../Footer/footer';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export default class RescheduleDelivery extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            citizenList: citizenList.citizens,
            displayModal: false,
            displayModalList: false,
            detailsDisplayed: '',
            // categoryName : this.props.categories,
            date: new Date(),
            dummyDate: (new Date().getDate()+1)+'/'+(new Date().getMonth()+1)+'/'+new Date().getFullYear(),
            dummyTime: [
                '04:00 - 04:10',
                '04:10 - 04:20',
                '04:20 - 04:30',
                '04:30 - 04:40',
                '04:40 - 04:50',
                '04:50 - 05:00'
            ],
            SMSFlag:false
        }

        // console.log("MINE",citizenList)
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;


    displayDetails = (value, index) => {
        this.setState({
            detailsDisplayed: value,
            displayModal: true
        })
    }

    scheduleDelivery =() => {
        
        this.setState({
            displayModalList: true
        })
    }

    citizenDetailsDisplayerModal = () => {
        return(
                        
<View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.5}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({displayModal: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 10, justifyContent: 'center', alignItems: 'center'}}>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                    <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Details of the citizen are as follows: </Text>
                </View>
                <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Name</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.name}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Mobile Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.mobileNumber}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Ration Card Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.rationNumber}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Age</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.age}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Category</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.category}</Text>
                        </View>
                        </View>
                    </View>
                </View>
            </View>
        )
    }
    citizenListDetailsDisplayerModal = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.7}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({displayModalList: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 10, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center',marginHorizontal: 0.02*this.width,paddingBottom:0.03*this.height}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic',color:"#fff"}}>The following citizens are to receive their rations at the new specified date and time. Click on "Submit" to send SMS with new date & time.</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center' ,flexDirection: 'row', paddingVertical: 0.02* this.height,  width:this.width*0.95}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold',color:"#fff"}}>Name</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold',color:"#fff"}}>Category</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold',color:"#fff"}}>Date & Time</Text>
                        </View>
                    </View>
                    {this.state.citizenList.map((value, index) => {
                        return(
                            this.displayCitizens(value, index)
                        )
                    })}
                    <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#fff'}} onPress={this.submitOTP}>
                            <Text style={{color: '#003399', fontWeight: 'bold', fontSize: 15}}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }
    displayCitizens = (value, index) => {
        return(
            <View key={index} style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                {/* <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center',borderColor:"#fff" ,backgroundColor: '#003399', borderRadius: 10}} > */}
                
                <View style={{justifyContent: 'center',marginHorizontal:0.02*this.width,borderRadius:10,borderWidth:1 ,borderColor:"#fff",alignItems: 'center', flexDirection: 'row'}}>
                    
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{value.name}</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{value.category}</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{this.state.dummyDate} {"\n"} {this.state.dummyTime[index]}</Text>
                        </View>
                    
                </View>
                {/* </TouchableOpacity> */}
            </View>
        )
    }
    submitOTP = () => {
        // this.state.citizenList.splice(this.state.indexDisplayed,1)
        this.setState({
            displayModalList: false,
            SMSFlag : true,
        })
    }
    renderCitizenList = (value, index) => {
        return(
            <View key={index} style={{justifyContent: 'center', alignItems: 'center',paddingVertical: '2%'}}>
                
                <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', backgroundColor: '#003399', width:this.width*0.95, borderRadius: 10}} onPress={() => this.displayDetails(value, index)}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.name}</Text>
                    </View>
                    <View style={{flex: 1,justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.mobileNumber}</Text>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.rationNumber}</Text>
                    </View>
                </TouchableOpacity>

            </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center'}}>
                <View style={{justifyContent: 'center', alignItems: 'center', marginTop:"15%"}}>
                    <Image style={{resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style = {{marginHorizontal: 0.05*width, justifyContent: 'center',backgroundColor: 'white'}} >
                        <Text style={ScheduleRationDeliveryStyle.productDetailsHeader}> Schedule Delivery </Text>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingTop: '15%'}}>
                    <View style={{justifyContent: 'center', alignItems: 'flex-start', marginHorizontal: 0.02*this.width,paddingBottom:0.03*this.height}}>
                        <Text style={{fontStyle: 15, fontWeight: 'bold', fontStyle: 'italic'}}>
                            Distribution of the ration/relief material will be rescheduled for the following citizens at 
                            the last hour of time of operation.                      
                        </Text>
                        <Text style={{fontStyle: 15, fontWeight: 'bold', fontStyle: 'italic'}}>
                            Click on each citizen to view their detail.                  
                        </Text>
                        <Text style={{fontStyle: 15, fontWeight: 'bold', fontStyle: 'italic'}}>
                           Click on Reschedule to continue.                    
                        </Text>
                    </View>
                    {this.state.SMSFlag ?null: <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', width: this.width*0.95}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Name</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Mobile No.</Text>
                            </View>

                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Ration Card No.</Text>
                            </View>
                        </View>
                    </View>}
                    
                    {this.state.SMSFlag ?
                    <View style={{justifyContent:"center",paddingVertical:0.05*this.height,paddingHorizontal:0.05*this.width}}>
                        <Text style={{fontSize:20,color:"grey"}}> There is no citizen ration delivery to be re-scheduled</Text>
                    </View>:
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        {this.state.citizenList.map((value, index) => {
                            return(this.renderCitizenList(value, index))
                            
                        })}
                    </View>
                    }
                </View>
              
                {this.state.SMSFlag ?null:
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop:"2%"}}>
                    <TouchableOpacity   style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} 
                                        onPress={this.scheduleDelivery}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Re-Schedule Delivery</Text>
                    </TouchableOpacity>
                </View>
                }
                

                <Modal
                    isVisible={this.state.displayModal == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.citizenDetailsDisplayerModal()}
                </Modal> 
                <Modal
                    isVisible={this.state.displayModalList == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.citizenListDetailsDisplayerModal()}
                </Modal> 
                    <Footer/>
            </View>
        )
    }
}


