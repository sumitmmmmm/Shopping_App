import React, { Component } from 'react';
import { StyleSheet, Dimensions, Text,TextInput, ScrollView ,View,Image,
    Button,TouchableOpacity, Animated,TouchableHighlight,KeyboardAvoidingView,AsyncStorage,TouchableWithoutFeedback,StatusBar,Keyboard,Platform } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Dropdown } from 'react-native-material-dropdown';
import { Bubbles, DoubleBounce, Bars, Pulse } from 'react-native-loader';
import global from '../../staticData/globalConfigurationFile';
import * as Permissions from "expo-permissions";
import Footer from '../../Footer/footer';
import categorySelectionStyle from './categorySelectionStyle'; 

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;    
export default class CategorySelection extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            hasCameraPermission: null,
            scanned: false,
            loaderForDistrict: true,
            loaderForSubDivison: false,
            loaderForBlock: false,
            isScannerOpen: false,
            visibleModal: null,
            QR_Code_Value: "",
            districtData:[],
            subDivisionData: [],
            district:'',
            subdivision:'',
            blockData:[],
            block:'',
            categories:"",
            categoriesData:[
                {
                    value: "ALL"
                },
                {
                    value: "AAY"
                },
                {
                    value: "AAY(JM)"
                },
                {
                    value: "AAY(NFSA)"
                },
                {
                    value: "AAY(PMGKAY)"
                },
                {
                    value: "AP"
                },
                {
                    value: "APL"
                },
                {
                    value: "BPL"
                },
                {
                    value: "FORM3Form4-Beneficiary"
                },
                {
                    value: "HPDS"
                },
                {
                    value: "ICDS"
                },
                {
                    value: "PHH"
                },
                {
                    value: "PHH(JM)"
                },
                {
                    value: "PHH(PMGKAY)"
                },
                {
                    value: "RKSY-I"
                },
                {
                    value: "RKSY-I(JM)"
                },
                {
                    value: "RKSY-II"
                },
                {
                    value: "RKSY-II(JM)"
                },
                {
                    value: "SPECIAL G.R"
                },
                {
                    value: "SPECIAL WELFARE SCHEME"
                },
                {
                    value: "SPHH"
                },
                {
                    value: "SPHH(JM)"
                },
                {
                    value: "TOTOPARA"
                },
                {
                    value: "WFD"
                }
            ],
            fps:'',
            fpsData:[
                {
                    value: "DEBASHISH BHATTACHARYA"
                },
                {
                    value: "ANIL SAYED"
                },
                {
                    value: "BIMAL KUMAR"
                },
                {
                    value: "ANKUR THAKUR"
                },
                {
                    value: "VIVEK PATRA"
                },
                {
                    value: "RITESH KUNJA"
                },
                
            ],
        }

        AsyncStorage.getItem("OwnerDetails")
        .then(response => JSON.parse(response))
        .then(json => {
            this.setState({
                firstName: json.firstName,
                lastName: json.lastName,
                licenseNo: json.licenseNo,
                mobileNumber: json.mobileNumber,
                shopName: json.shopName,
                subDivision: json.subDivision,
                block: json.block,
                dob: json.dob,
                district: json.district
            })
        })

    }

    // searchSubDivisions = (index) => {
    //     this.setState({
    //         loaderForSubDivison: true
    //     })
    //     let DistrictId = this.state.districtData[index].id;
    //     console.log('DISTRICT', DistrictId)
        
    //     fetch(global.ipAddr + global.district + "/" + DistrictId + '/subdivisions', {
    //         method: 'GET',
    //         headers: {
    //             'Content-Type': 'application/json',
    //             'Authorization': this.state.token 
    //         },
    //     })
    //     .then(response => response.json())
    //     .then(json => {
    //         console.log(json)
    //         this.state.subDivisionData = [];
    //         if(json.length != 0){
    //             json.map((value, index) => {
               
    //                 this.setState(prevState => ({
    //                     subDivisionData: [...prevState.subDivisionData, {
    //                         value: value.SubDivisionName,
    //                         id: value.SubDivisionId
    //                     }]
    //                 }))
    //                 this.setState({
    //                     loaderForSubDivison: false
    //                 })
    //             })
    //         }
    //         else{
    //             this.setState({
    //                 loaderForSubDivison: false
    //             })
    //         }
            
    //     })
    // }

    // searchBlocks = (index) => {
    //     this.setState({
    //         loaderForBlock: true
    //     })
    //     let SubDivisionId = this.state.subDivisionData[index].id;
        
    //     fetch(global.ipAddr + global.subDivisions + "/" + SubDivisionId + '/blocks', {
    //         method: 'GET',
    //         headers: {
    //             'Content-Type': 'application/json',
    //             'Authorization': this.state.token 
    //         },
    //     })
    //     .then(response => response.json())
    //     .then(json => {
    //         this.state.blockData = [];
    //         json.map((value, index) => {
                
    //             this.setState(prevState => ({
    //                 blockData: [...prevState.blockData, {
    //                     value: value.BlockName,
    //                     id: value.BlockId
    //                 }]
    //             }))
    //             this.setState({
    //                 loaderForBlock: false
    //             })
    //         })
    //     })
    // }

      nextButton = () =>{
        this.setState({visibleModal:null});
        
      }
      
      submitDetails = () =>{
     
            console.log(this.state.categories);
            Actions.CitizenListScreen({categories: this.state.categories})
      }
    
    handleChange =(event)=> {
        const {name, type, text} = event;
        let processedData = text;
        if(type==='text') {
            processedData = value.toUpperCase();
        } else if (type==='number') {
            processedData = value * 2;
        }
        this.setState({[name]: processedData})
    }
   
    render(){
        
        return(
            <KeyboardAvoidingView style={{flex:1, backgroundColor: 'white'}}>
               
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} >
                <View style={{flex:1}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                        <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                    </View>
                
                    <View style = {{flex: 1, justifyContent: 'center',backgroundColor: 'white',marginHorizontal: 0.05*width, marginBottom: '5%'}} >
                            <Text style={categorySelectionStyle.productDetailsHeader}>Ration Dealer Details</Text>
                    </View>
                    
                    <View style = {{flex: 4, backgroundColor: 'white',marginHorizontal: 0.03*width, marginBottom: '5%', borderWidth: 2, borderRadius: 20, borderTopWidth: 5, borderBottomWidth: 5, borderColor: '#003399', justifyContent: 'center'}} >
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginLeft: '10%', paddingVertical: '2%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>District</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 15, fontStyle: 'italic'}}>{this.state.district}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row',  marginLeft: '10%', paddingVertical: '2%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>Sub-Division</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 15, fontStyle: 'italic'}}>{this.state.subDivision}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row',  marginLeft: '10%', paddingVertical: '2%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>Block</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 15, fontStyle: 'italic'}}>{this.state.block}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginLeft: '10%', paddingVertical: '2%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>Dealer Name</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 15}}>{this.state.firstName} {this.state.lastName}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginLeft: '10%', paddingVertical: '2%'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>Mobile Number</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'flex-start', alignItems: 'flex-start'}}>
                                <Text style={{color: '#003399', fontSize: 15, fontStyle: 'italic'}}>{this.state.mobileNumber}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginLeft: '10%'}}>
                            <View style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}} >
                                <Text style={{color: '#003399', fontSize: 20, fontWeight: 'bold'}}>Categories</Text>
                            </View>
                            <View style = {{flex: 1, justifyContent: 'center', alignItems: 'flex-start'}} >
                                <Dropdown
                                    placeholder='Select Categories'
                                    data={this.state.categoriesData}
                                    fontSize={14}
                                    itemColor={"black"}
                                    baseColor={"#003399"}
                                    selectedItemColor={"#003399"}
                                    containerStyle={categorySelectionStyle.dropdownInput}
                                    textColor={"#003399"}
                                    dropdownMargins={{min:0,max:0}}
                                    dropdownOffset={{top:0,left:2}}
                                    inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height, width: '100%'}}
                                    pickerStyle={{paddingHorizontal:0.02*width}}
                                    onChangeText={(value) => {this.setState({categories : value})}}
                                />
                            </View>
                        </View>
                    </View>

                    <View style={{flex: 1,marginTop:"2%", justifyContent: 'center', alignItems: 'center'}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.submitDetails}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                    
                    </View>
                    </TouchableWithoutFeedback>
                     <Footer/>
            </KeyboardAvoidingView>
        )
    }
}