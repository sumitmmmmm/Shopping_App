import React, { Component } from 'react';
import { StyleSheet, Dimensions, Text,TextInput, ScrollView ,View,Image,
    Button,TouchableOpacity, Animated,TouchableHighlight,KeyboardAvoidingView,TouchableWithoutFeedback,StatusBar,Keyboard,Platform } from 'react-native';
// import { Actions } from 'react-native-router-flux';
// import Modal from 'react-native-modal';
// import Constants from "expo-constants";
import * as Permissions from "expo-permissions";
import Footer from '../../Footer/footer';
// import { BarCodeScanner } from "expo-barcode-scanner";
// import SideBar from '../Header/sideBar';
import categorySelectionStyle from './categorySelectionStyle'; 
import { Actions } from 'react-native-router-flux';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;    
export const MyTextInput = ({ value, name,placeholder, type, onChange }) => {
    return (
      <TextInput style={categorySelectionStyle.textInput}
      placeholder={placeholder}
        value={value}
        onChangeText={text => onChange({ name, type, text })}
      />
    );
  };