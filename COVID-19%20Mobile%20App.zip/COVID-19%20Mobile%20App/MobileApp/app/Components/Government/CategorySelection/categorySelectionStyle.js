import React,{StyleSheet, Dimensions} from 'react-native';
// import Dimentions from 'Dimensions';
import Constants from 'expo-constants';
// import { Reducer } from 'react-native-router-flux';
// import { color } from 'd3-color';
// const DEVICE_WIDTH = Dimentions.get('window').width;
// const DEVICE_HEIGHT = Dimentions.get('window').height;
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;    
export default StyleSheet.create({

statusBar:{
    height: Constants.statusBarHeight,

},
inputfieldtext: {
    fontSize: 18,
    fontStyle: 'italic',
    color: '#003399',
    fontWeight: 'bold'
},
inputfieldtextSub: {
    fontSize: 14,
    color: '#003399',
    fontWeight: 'bold'
},
inputfieldtextView:{
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    paddingHorizontal:0.02*width
},
loginFormButtonScanContainer:{
    backgroundColor: '#d93954',
    alignItems:"center",
    height:60,
    width:60,
    justifyContent:'center',
    paddingHorizontal:'4%',
    borderRadius: 60,
},

loginFormButtonSubmitContainer:{
    backgroundColor: '#d93954',
    paddingVertical: "2%",
    alignItems:"center",
    // flexDirection:"row",
    height:40,
    width:100,
    paddingHorizontal:'4%',
    marginLeft: '67%',
    borderRadius: 10,
},

productDetailsHeader:{
    // flex:1,
    backgroundColor: 'white',
    color: '#003399',
    fontWeight: 'bold',
    fontSize:25, 
    textAlign:"center",
    marginLeft:'5%'
},
textInput:{
    height: 0.05*height,
    backgroundColor: 'white',
    borderRadius: 0.01*height, 
    borderWidth:1, 
    borderColor:"#003399",
    color:"#003399",
    paddingHorizontal:"3%"
},
dropdownInput:{
    width: '95%',
    // height: 0.05*height,
    backgroundColor: 'white',
    borderRadius: 0.01*height, 
    borderWidth:1, 
    borderColor:"#003399",
    // color:"#003399",
    paddingHorizontal:"3%",
    
},
loginFormNextContainer:{
    backgroundColor: '#d93954',
    alignItems:"center",
    height:40,
    width:100,
    justifyContent:'center',
    paddingHorizontal:'4%',
    borderRadius:10, 
    // marginBottom:'2%',
    paddingVertical:'-1%'
},

productDetailsinput1:{
    flex:1,
    backgroundColor: 'white',
    color: 'black',
    fontWeight: 'bold',
    padding : 6
},

productDetailsinput:{
    fontSize: 15,
    color: '#2d2d2d',
    padding: 6
},

})

