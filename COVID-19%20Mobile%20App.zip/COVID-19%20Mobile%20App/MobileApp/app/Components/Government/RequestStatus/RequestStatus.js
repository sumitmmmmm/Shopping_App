

import React from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView, KeyboardAvoidingView} from 'react-native';
import { Actions } from 'react-native-router-flux';
// import MultiSelect from 'react-native-multiple-select';
// import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
import RequestStatusStyle from './RequestStatusStyle'
// import Map from '../../Map/map'
import * as citizenList from '../../staticData/citizenList';
import Footer from '../../Footer/footer';
const height = Dimensions.get("window").height;
const width = Dimensions.get("window").width;
export default class RequestStatus extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            citizenList: citizenList.citizens,
            displayModal: false,
            detailsDisplayed: '',
            categoryName : this.props.categories,
        }

        // console.log("MINE",citizenList)
    }




    displayDetails = (value, index) => {
        this.setState({
            detailsDisplayed: value,
            displayModal: true
        })
    }



    renderCitizenList = (value, index) => {
        return(
            <View key={index} style={{justifyContent: 'center', alignItems: 'center',paddingVertical: '2%'}}>
                
                <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', backgroundColor: '#003399', width:width*0.95, borderRadius: 10}} onPress={() => this.displayDetails(value, index)}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.name}</Text>
                    </View>
                    <View style={{flex: 1,justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.mobileNumber}</Text>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.rationNumber}</Text>
                    </View>
                </TouchableOpacity>

            </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center'}}>
                <View style = {{height : 0.08*height, justifyContent: 'center',backgroundColor: 'white',marginHorizontal: 0.05*width,marginTop:0.02*height}} >
                        <Text style={RequestStatusStyle.productDetailsHeader}>Request Status</Text>
                </View>
                <View style={{flex: 3, justifyContent: 'center', alignItems: 'center'}}>
                    
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', width: width*0.95}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Sl No.</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Request Date</Text>
                            </View>

                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Status</Text>
                            </View>
                        </View>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        {this.state.citizenList.map((value, index) => {
                            return(this.renderCitizenList(value, index))
                            
                        })}
                    </View>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop:"0%"}}>
                    <Image style={{flex: 1, resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>

                    <Footer/>
            </View>
        )
    }
}


