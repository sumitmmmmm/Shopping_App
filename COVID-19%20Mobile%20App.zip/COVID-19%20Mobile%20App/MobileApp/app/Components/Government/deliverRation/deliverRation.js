import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView} from 'react-native';
// import { Actions } from 'react-native-router-flux';
// import MultiSelect from 'react-native-multiple-select';
// import { Dropdown } from 'react-native-material-dropdown';
import { Bars } from 'react-native-loader';
import Modal from 'react-native-modal'
import Map from '../../Map/map'
import Footer from '../../Footer/footer'
import global from '../../staticData/globalConfigurationFile';
import * as citizenList from '../../staticData/citizenList'

export default class DeliverRation extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            generatedOTP: false,
            citizenList: [],
            OTP: '',
            correctOTP : 123456,
            
            modalDisplayer: false,
            detailsDisplayed: '',
            loader : false,
            submittedOTP : false,
            successForOTP : false,
            failureForOTP : false,
            dummyDate: [
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020',
                '04/05/2020'
            ],
            dummyTime: [
                '10:00 - 10:10',
                '10:10 - 10:20',
                '10:20 - 10:30',
                '10:30 - 10:40',
                '10:40 - 10:50',
                '10:50 - 11:00',
                '11:00 - 11:10',
                '11:10 - 11:20',
                '11:20 - 11:30',
                '11:30 - 11:40',
                '11:40 - 11:50',
                '11:50 - 12:00',
                '12:00 - 12:10',
                '12:10 - 12:20',
                '12:20 - 12:30',
                '12:30 - 12:40',
                '12:40 - 12:50',
                '12:50 - 01:00',
                '01:00 - 01:10',
                '01:10 - 01:20',
                '01:20 - 01:30',
                '01:30 - 01:40',
                '01:40 - 01:50',
                '01:50 - 02:00',
                '02:00 - 02:10',
                '02:10 - 02:20',
                '02:20 - 02:30',
                '02:30 - 02:40',
                '02:40 - 02:50',
                '02:50 - 02:00',
                '03:00 - 03:10',
                '03:10 - 03:20',
                '03:20 - 03:30',
                '03:30 - 03:40',
                '03:40 - 03:50',
                '03:50 - 04:00'
            ]
        }
        AsyncStorage.getItem('jwtToken')
        .then(response => JSON.parse(response))
        .then(json => {
            console.log(json)
            this.setState({
                token: json
            })
            fetch(global.ipAddr + global.consumers, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': json
                }
            })
            .then(response => response.json())
            .then(json => {
                this.setState({
                    citizenList: json
                })
            })
        })

    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    getDetails = (value, index) => {
        this.setState({
            failureForOTP : false,
            generatedOTP : false,
            detailsDisplayed: value,
            modalDisplayer: true,
            indexDisplayed: index
        })
    }

    generateOTP = () => {
        var correctOTP = Math.floor(100000 + Math.random() * 900000); 
        this.state.correctOTP = correctOTP;
        this.state.OTP = '',
        this.setState({
            generatedOTP: true,
            loader : true,            
        })
        this.sendMessage();
    }

    sendMessage = () => {
        console.log(this.state.correctOTP);
        fetch( global.ipAddr + global.sendMessage, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': this.state.token
            },
            body: JSON.stringify({
                "Mobile": this.state.detailsDisplayed.MobileNo,
                'Message': `Your OTP is ${this.state.correctOTP}.`
            })
        })
        .then(response => response.json())
        .then(json => {
            this.setState({
                displaySuccess: true,
                loader : false,
            })
        })
        .catch(error => console.log(error))
    }

    submitOTP = () => {
        // this.setState({
        //     generatedOTP : false,
        //     loader : true,
        // })
        // if(this.state.OTP == this.state.correctOTP){
            this.setState({
                modalDisplayer: false,
                submittedOTP : true,
                successForOTP : true
            })
            this.state.citizenList.splice(this.state.indexDisplayed,1)
        // } else{
        //     this.setState({
        //         submittedOTP : false,
        //         failureForOTP : true
        //     })
        // }
    }

    modalDisplayForCitizen = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.8}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({modalDisplayer: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{flex: 1, resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>

                <View style={{flex: 6, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Details of the citizen are as follows: </Text>
                    </View>
                    <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Name</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.FirstName} {this.state.detailsDisplayed.LastName}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Date of Pickup</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.dummyDate[this.state.indexDisplayed]}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Time of Pickup</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.dummyTime[this.state.indexDisplayed]}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Mobile Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.MobileNo}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Ration Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.RationNo}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Age</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.Age}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Category</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.Category}</Text>
                        </View>
                        </View>
                    </View>
                </View>

                {this.state.generatedOTP == false ? 
                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%', textAlign: 'center'}}>
                        <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff', fontStyle: 'italic'}}>Click on the button to generate OTP</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'red'}}
                             onPress={this.generateOTP}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Generate OTP</Text>
                            </TouchableOpacity>
                        </View>
                </View>:null
                
                }
                {/* {this.state.loader == true ? 
                    
                    : null
                } */}
                {this.state.generatedOTP == true ? 
                
                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                    {this.state.loader ? 
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff'}}>Please wait...</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Bars size={10} color= '#fff' />
                            </View>
                        </View>
                        :
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%', textAlign: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff', fontStyle: 'italic',textAlign : "center"}}>Enter the OTP sent to {this.state.detailsDisplayed.FirstName} {this.state.detailsDisplayed.LastName} and click on Submit to confirm the transaction: </Text>
                        </View>
                    }
                     {this.state.failureForOTP ?
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic', color: '#fff', textAlign: 'center'}}>
                                Entered OTP is incorrect, please try again.
                            </Text>
                        </View>
                    :null
                    }
                    <View style={{justifyContent: 'center', alignItems: 'center', width: this.width*0.5}}>
                        <TextInput
                            style={{borderColor: 'gray', backgroundColor: '#fff', color: 'black', borderRadius:10, borderWidth: 1, textAlign: 'center', width: '100%', height: this.height*0.07}}
                            placeholder='Enter OTP'
                            value={this.state.OTP}
                            onChangeText={(text) => this.setState({OTP: text})}
                            keyboardType="number-pad"
                            maxLength={6}
                            minLength={6}
                        />
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'red'}}
                         onPress={this.submitOTP}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                </View>: null    
            
                }

               
            </View>
        )
    }

    displayCitizens = (value, index) => {
        return(
            <View key={index} style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', backgroundColor: '#003399', width:this.width*0.95, borderRadius: 10}} onPress={() => this.getDetails(value, index)}>
                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                    
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{value.FirstName} {value.LastName}</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{value.Category}</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                            <Text style={{fontSize: 12, color: '#fff'}}>{this.state.dummyDate[index]} {"\n"} {this.state.dummyTime[index]}</Text>
                        </View>
                    
                </View>
                </TouchableOpacity>
            </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1}}>
                
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: '15%'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 6, alignItems: 'center', marginBottom: '2%'}}>
                    <View style={{ alignItems: 'center',marginHorizontal: 0.02*this.width,paddingBottom:0.03*this.height}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic'}}>The following citizens will receive their ration at the notified date and time. Click on the citizen to view their details and verify their OTP.</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: 0.02* this.height,  width:this.width*0.95}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold'}}>Name</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold'}}>Category</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 15, fontWeight: 'bold'}}>Date & Time</Text>
                        </View>
                    </View>
                    <ScrollView>
                    {this.state.citizenList.map((value, index) => {
                        return(
                            this.displayCitizens(value, index)
                        )
                    })}
                    </ScrollView>
                </View>
                

                <Modal
                    isVisible={this.state.modalDisplayer == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.modalDisplayForCitizen()}
                </Modal>
                <Modal
                    isVisible={this.state.submittedOTP == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.4}}>
                        <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                            <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} 
                                onPress={() => {this.setState({
                                    submittedOTP: false,
                                    loader : false,
                                    OTP: '',
                                    generatedOTP : false,
                                    successForOTP: false})}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Image style={{flex: 1, resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                        </View>
                        <View style={{flex: 3, justifyContent: 'center', alignItems: 'center'}}>
                            {this.state.successForOTP ? 
                                <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic', color: '#fff', textAlign: 'center'}}>
                                        OTP successfully verified, Ration Delivery Successful.
                                    </Text>
                                </View>
                                : 
                                null
                            }
                        </View>
                    </View>
                </Modal>
              
                <Footer/>
            </View>
        )
    }
}