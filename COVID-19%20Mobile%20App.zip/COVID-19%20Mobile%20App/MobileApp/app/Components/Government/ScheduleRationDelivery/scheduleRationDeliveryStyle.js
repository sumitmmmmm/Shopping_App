import React,{StyleSheet, Dimensions} from 'react-native';
import Constants from 'expo-constants';
const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

export default StyleSheet.create({
    productDetailsHeader:{
        backgroundColor: 'white',
        color: '#003399',
        fontWeight: 'bold',
        fontSize:21, 
        textAlign:"center",
        marginLeft:'5%'
    },
    inputfieldtext: {
        flex:1,
        backgroundColor: 'white',
        color: '#003399',
        fontWeight: 'bold'
    },
    textInput:{
        height: 0.05*height,
        backgroundColor: 'white',
        borderRadius: 0.01*height, 
        borderWidth:1, 
        borderColor:"#003399",
        color:"#003399",
        paddingHorizontal:"3%"
    },
    rationCategory : {
        width:"30%", 
        fontSize:14, 
        marginTop:'5%',
        color:"#003399",
    },
    rationCategoryInModal : {
        width:"20%", 
        fontSize:14, 
        marginTop:'5%',
        marginLeft:"10%",
        color:"white",
    },
    rationInModal : {
        // width: "70%", 
        textAlign: "left",
        fontSize:14, 
        marginTop:'5%',
        // marginLeft:"10%",
        color:"white",
    },
    modalClosebuttonX : {
        justifyContent: 'center', 
        alignItems: 'center', 
        height: height*0.04, 
        width: height*0.04, 
        borderRadius: height*0.02, 
        backgroundColor: '#fff'
    },
    dropdownInput:{
        // height: 0.05*height,
        backgroundColor: 'white',
        borderRadius: 0.01*height, 
        borderWidth:1, 
        borderColor:"#003399",
        // color:"#003399",
        paddingHorizontal:"3%",
        
    },
})

