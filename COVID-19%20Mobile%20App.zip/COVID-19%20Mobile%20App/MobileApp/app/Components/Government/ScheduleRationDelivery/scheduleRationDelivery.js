import React from 'react';
import { Dimensions, Text, ScrollView ,View,Image,TouchableOpacity, AsyncStorage } from 'react-native';
import ScheduleRationDeliveryStyle from './scheduleRationDeliveryStyle';
import TimePicker from 'react-native-simple-time-picker';
import MultiSelect from 'react-native-multiple-select';
import Footer from '../../Footer/footer';
import Modal from 'react-native-modal';
import { Dropdown } from 'react-native-material-dropdown';
import global from '../../staticData/globalConfigurationFile';
import * as RationDataCategoryWise from '../../staticData/rationDataCategoryWise';
import * as ScheduleTimeData from '../../staticData/scheduleTime';
// import scheduleRationDeliveryStyle from './scheduleRationDeliveryStyle';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
export default class ScheduleRationDeliveryScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            displaySuccess: false,
            startSelectedHours: 10,
            startSelectedMinutes: 0,
            endSelectedHours: 17,
            endSelectedMinutes: 0,
            breakTimeSelectedHours : "2:00",
            breakTimeSelectedMinutes : 30,
            selectedTimeSlot : 10,
            selectedItems: [],
            wheat : 0,
            rice : 0,
            oil : 0,
            sugar : 0,
            kerosene : 0,
            dummy : 0,
            displayModal: false,
            categoryName : this.props.categoryName,
            citizenList : this.props.citizenList,
            items: [
                {
                    id: 'sunday',
                    name: 'Sunday',
                },
                {
                    id: 'monday',
                    name: 'Monday',                    
                },
                {
                    id: 'tuesday',
                    name: 'Tuesday',
                },
                {
                    id: 'wednesday',
                    name: 'Wednesday',
                },
                {
                    id: 'thursday',
                    name: 'Thursday',
                },
                {
                    id: 'friday',
                    name: 'Friday',
                },
                {
                    id: 'saturday',
                    name: 'Saturday',
                }
            ],
            RationDataCategoryWise : RationDataCategoryWise.RationData,
            HourData : ScheduleTimeData.HourData,
            MinutesData : ScheduleTimeData.MinutesData,
            breakTimeData : ScheduleTimeData.breakTimeData,
            timeSlotData : ScheduleTimeData.timeSlotData,
        }
        this.preFilledRationData();
        AsyncStorage.getItem('jwtToken')
        .then(response => JSON.parse(response))
        .then(json => {
            console.log(json)
            this.setState({
                token: json
            })
        })

        for(let i=0; i<this.state.citizenList.length; i++){
            this.state.citizenList[i].ScheduleId = this.generateScheduleId();
            this.state.citizenList[i].StartTime = "2020-05-06T08:30:00.534Z";
            this.state.citizenList[i].EndTime = "2020-05-06T08:40:00.534Z";
            this.state.citizenList[i].OwnerId = this.generateScheduleId();
            this.state.citizenList[i].ConsumerId = this.generateScheduleId();
            this.state.citizenList[i].OwnerName = this.state.citizenList[i].FirstName + " " + this.state.citizenList[i].LastName;
            this.state.citizenList[i].CustomerName = this.state.citizenList[i].FirstName + " " + this.state.citizenList[i].LastName;
            this.state.citizenList[i].DateOfDelivery = "2020-05-06T08:30:00.534Z";
            // this.state.citizenList[i].MessageStatus = "Ration delivery date is scheduled.";
            this.state.citizenList[i].OwnerAddress = "string";
            this.state.citizenList[i].DayOfDelivery = "Wednesday";
            this.state.citizenList[i].Mobile = this.state.citizenList[i].MobileNo;
        }
        console.log(this.state.citizenList);
    }

    onSelectedItemsChange = (selectedItems, index) => {
        // console.log("SELECT", index)
        this.setState({selectedItems: selectedItems})
    }

    preFilledRationData = () => {
        for(let i=0;i<23; i++){
            if(this.state.RationDataCategoryWise[i].name == this.state.categoryName ){
                var wheat = this.state.RationDataCategoryWise[i].wheat;
                var rice = this.state.RationDataCategoryWise[i].rice;
                var oil = this.state.RationDataCategoryWise[i].oil;
                var sugar = this.state.RationDataCategoryWise[i].sugar;
                var kerosene = this.state.RationDataCategoryWise[i].kerosene;
                this.state.wheat = JSON.stringify(wheat);
                this.state.rice = JSON.stringify(rice);
                this.state.oil = JSON.stringify(oil);
                this.state.sugar = JSON.stringify(sugar);
                this.state.kerosene = JSON.stringify(kerosene);
            }
        }
    }

    generateScheduleId = () => {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
          });
    }

    sendMessage = () => {

        console.log("Sending...", this.state.token)
        fetch( global.ipAddr + global.schedules, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': this.state.token
            },
            body: JSON.stringify(this.state.citizenList)
        })
        .then(response => response.json())
        .then(json => {
            console.log(json);
            this.setState({
                displaySuccess: true
            })
        })
        .catch(error => console.log(error))       
    }

    showDetialsInModal  = () => {
        return(
            <View style={{justifyContent:"center", backgroundColor: '#003399', borderRadius: 40, height: height*0.7}}>
                <View style={{alignItems: 'flex-end', marginRight: '5%', marginTop:"2%"}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: height*0.04, width: height*0.04, borderRadius: height*0.02, backgroundColor: '#fff'}} 
                                    onPress={() => {this.setState({displayModal: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <ScrollView style={{height:"90%"}}>
                    <View style={{ padding: "3%", flex:1, justifyContent:"center"}}>
                        <Text style={{fontSize:16,fontWeight:'bold',textAlign:'center', color:"white"}}>
                             Ration Delivery Schedule 
                        </Text>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategoryInModal}>
                                Start Time :
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationInModal}>
                                {this.state.startSelectedHours} : {this.state.startSelectedMinutes} Hrs 
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategoryInModal}>
                                End Time :
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationInModal}>
                                {this.state.endSelectedHours} : {this.state.endSelectedMinutes} Hrs
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategoryInModal}>
                                Days : 
                            </Text>
                            {this.state.selectedItems.map((value, index) => {
                                return(
                                    <Text key={index} style={ScheduleRationDeliveryStyle.rationInModal}>
                                        {value=="tuesday" || value=="thursday" ? value.toUpperCase().substring(0,4)+ " " : value.toUpperCase().substring(0,3)+ " " }
                                    </Text>
                                ) 
                            })}
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategoryInModal}>
                                Wheat :
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationInModal}>
                                {this.state.wheat} Kg
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategoryInModal}>
                                Rice :
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationInModal}>
                                {this.state.rice} Kg
                            </Text>
                        </View>
                       
                    </View>
                    {this.state.displaySuccess == false ? 
                        <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:"8%", paddingBottom:"2%"}}>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                                <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff', textAlign: 'center'}}>
                                    Click on the button below to send an SMS to all the customers in the  list.
                                </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={() => this.sendMessage()}>
                                <Text style={{fontSize: 13, fontWeight: 'bold', color: '#003399'}}>Confirm Schedule</Text>
                            </TouchableOpacity>
                            </View>
                        </View>: null
                
                    }
                    {this.state.displaySuccess == true ?
                    
                    <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:"8%", paddingBottom:"2%"}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                            <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/registered_successful_tick.png')} />
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', color: '#fff', textAlign: 'center'}}>SMS sent to all the citizens in the list. Click on Close to close this window</Text>
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: 'white'}} onPress={() => this.setState({displayModal: false})}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15, color: '#003399'}}>Close</Text>
                            </TouchableOpacity>
                            </View>
                    
                    </View>:null
                
                    }
                    
                </ScrollView>
            </View>
        )
    }

    submitDetails =() => {
        this.setState({
            displayModal : true,
        })
    }

    render ( ) {
        return(
            <View style={{flex:1, backgroundColor: 'white'}}>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: '15%'}}>
                    <Image style={{resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style = {{height : 0.03*height, marginHorizontal: 0.05*width, marginTop: "10%", justifyContent: 'center',backgroundColor: 'white'}} >
                        <Text style={ScheduleRationDeliveryStyle.productDetailsHeader}> Schedule Delivery </Text>
                </View>
                <ScrollView style={{ marginTop:'2%' }}>
                    <View style={{ height: 0.08*height, marginHorizontal: 0.05*width, marginTop:'2%' }}>
                        <View style = {{height: 0.03*height,justifyContent: 'center',backgroundColor: '#DCDCDC'}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>Start Time</Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={{width:"50%", fontSize:10}}>
                                Hours
                            </Text>
                            <Text style={{width:"50%", fontSize:10}}>
                                Minutes
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Hours'
                                        data={this.state.HourData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({startSelectedHours : value})}}
                                />
                            </View>
                            <View style={{width : "10%"}}>
                            </View>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Minutes'
                                        data={this.state.MinutesData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({startSelectedMinutes : value})}}
                                />
                            </View>
                        </View>
                    </View>
                    <View style={{ height: 0.08*height, marginHorizontal: 0.05*width, marginTop:'10%' }}>
                        <View style = {{height: 0.03*height,justifyContent: 'center',backgroundColor: '#DCDCDC'}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>End Time</Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={{width:"50%", fontSize:10}}>
                                Hours
                            </Text>
                            <Text style={{width:"50%", fontSize:10}}>
                                Minutes
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Hours'
                                        data={this.state.HourData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({endSelectedHours : value})}}
                                />
                            </View>
                            <View style={{width : "10%"}}>
                            </View>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Minutes'
                                        data={this.state.MinutesData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({endSelectedMinutes : value})}}
                                />
                            </View>
                        </View>
                    </View>
                    <View style={{ height: 0.06*height, marginHorizontal: 0.05*width, marginTop:'12%',flexDirection: 'row' }}>
                        <View style = {{height: 0.06*height,justifyContent: 'center',backgroundColor: '#DCDCDC', width : "40%"}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>Time slot for Ration Distribution <Text style={{color:"black",fontSize:10}}> &nbsp;&nbsp;&nbsp;(min)</Text> </Text>
                        </View>
                        <View style={{width: "10%"}}></View>
                        <View style={{width : "40%"}}>
                            <Dropdown
                                    placeholder='Select Time Slot'
                                    data={this.state.timeSlotData}
                                    fontSize={14}
                                    itemColor={"black"}
                                    baseColor={"#003399"}
                                    selectedItemColor={"#003399"}
                                    containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                    textColor={"#003399"}
                                    dropdownMargins={{min:0,max:0}}
                                    dropdownOffset={{top:0,left:2}}
                                    inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                    pickerStyle={{paddingHorizontal:0.02*width}}
                                    onChangeText={(value) => {this.setState({selectedTimeSlot : value})}}
                            />
                        </View>
                    </View>
                    <View style={{ height: 0.10*height, marginHorizontal: 0.05*width, marginTop:'3%' }}>
                        <View style = {{height: 0.03*height,justifyContent: 'center',backgroundColor: '#DCDCDC'}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>Break Time</Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={{width:"50%", fontSize:10}}>
                                Hours
                            </Text>
                            <Text style={{width:"50%", fontSize:10}}>
                                Break time in Minutes
                            </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Hours'
                                        data={this.state.breakTimeData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({breakTimeSelectedHours : value})}}
                                />
                            </View>
                            <View style={{width : "10%"}}>
                            </View>
                            <View style={{width : "40%"}}>
                                <Dropdown
                                        placeholder='Select Minutes'
                                        data={this.state.MinutesData}
                                        fontSize={14}
                                        itemColor={"black"}
                                        baseColor={"#003399"}
                                        selectedItemColor={"#003399"}
                                        containerStyle={ScheduleRationDeliveryStyle.dropdownInput}
                                        textColor={"#003399"}
                                        dropdownMargins={{min:0,max:0}}
                                        dropdownOffset={{top:0,left:2}}
                                        inputContainerStyle={{borderBottomColor: 'transparent',marginTop:0.01*height}}
                                        pickerStyle={{paddingHorizontal:0.02*width}}
                                        onChangeText={(value) => {this.setState({breakTimeSelectedMinutes : value})}}
                                />
                            </View>
                        </View>
                    </View>
                    <View style={{ marginHorizontal: 0.05*width, marginTop: 0.02*height, marginTop:'7%' }}>
                        <View style = {{height: 0.03*height, justifyContent: 'center', backgroundColor: '#DCDCDC'}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>Days of Operation </Text>
                        </View>
                        <View style={{  borderRadius: 20, zIndex: 999}}>
                            <MultiSelect
                                hideTags
                                items={this.state.items}
                                uniqueKey="id"
                                ref={(component) => { this.multiSelect = component }}
                                onSelectedItemsChange={(value, index) => this.onSelectedItemsChange(value, index)}
                                selectedItems={this.state.selectedItems}
                                selectText="Select Days"
                                searchInputPlaceholderText="Search Days..."
                                onChangeInput={ (text)=> console.log(text)}
                                tagRemoveIconColor="#CCC"
                                tagBorderColor="#CCC"
                                tagTextColor="#CCC"
                                selectedItemTextColor="#003399"
                                selectedItemIconColor="#CCC"
                                itemTextColor="#000"
                                displayKey="name"
                                styleDropdownMenuSubsection={{borderRadius: 20}}
                                styleSelectorContainer={{borderRadius: 20}}
                                styleTextDropdownSelected={{fontStyle: 'italic'}}
                                searchInputStyle={{ color: '#CCC' }}
                                submitButtonColor="#003399"
                                submitButtonText="Submit"
                            />
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>
                                    Selected Days :
                                </Text>
                            </View>
                            {this.state.selectedItems.map((value, index) => {
                                return(
                                    <View key={index} style={{justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 13, fontWeight: 'bold', textAlign: 'center', marginBottom: '3%'}}>
                                            {value.toUpperCase()}
                                        </Text>
                                    </View>
                                )
                            })}
                        </View>
                    </View>
                    <View style={{ marginHorizontal: 0.05*width, marginTop:'2%' }}>
                        <View style = {{height: 0.03*height,justifyContent: 'center',backgroundColor: '#DCDCDC'}} >
                            <Text style={ScheduleRationDeliveryStyle.inputfieldtext}>Ration Quantity </Text>
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                Wheat : 
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                    {this.state.wheat} Kg
                            </Text>
                            {/* <View style = {{flex:1, paddingVertical:'2%'}}>
                                <TextInput style={ScheduleRationDeliveryStyle.textInput} 
                                value= {this.state.wheat}
                                name="wheat"
                                onChangeText={(text) => this.setState({wheat: text})}/>
                            </View> */}
                        </View>
                        <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                Rice :
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                    {this.state.rice} Kg
                            </Text>
                            {/* <View style = {{flex:1 , paddingVertical:'2%'}}>
                                <TextInput style={ScheduleRationDeliveryStyle.textInput}
                                value={this.state.rice}
                                name="rice"
                                onChangeText={(text) => this.setState({rice: text})}/>
                            </View> */}
                        </View>
                        {/* <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                Oil : 
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                {this.state.oil} L
                            </Text> */}
                            {/* <View style = {{flex:1 , paddingVertical:'2%'}}>
                                <TextInput style={ScheduleRationDeliveryStyle.textInput}
                                editable={false}
                                value={this.state.oil}
                                name="oil"
                                onChangeText={(text) => this.setState({oil: text})}/>
                            </View> */}
                        {/* </View> */}
                        {/* <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                Sugar : 
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                {this.state.sugar} Kg
                            </Text> */}
                            {/* <View style = {{flex:1, paddingVertical:'2%' }}>
                                <TextInput style={ScheduleRationDeliveryStyle.textInput}
                                editable={false}
                                value={this.state.sugar}
                                name="sugar"
                                onChangeText={(text) => this.setState({sugar: text})}/>
                            </View> */}
                        {/* </View> */}
                        {/* <View style={{flexDirection: 'row'}}>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                Kerosene : 
                            </Text>
                            <Text style={ScheduleRationDeliveryStyle.rationCategory}>
                                {this.state.kerosene} L
                            </Text> */}
                            {/* <View style = {{flex:1, paddingVertical:'2%' }}>
                                <TextInput style={ScheduleRationDeliveryStyle.textInput}
                                editable={false}
                                value={this.state.kerosene}
                                name="kerosene"
                                onChangeText={(text) => this.setState({kerosene: text})}/>
                        </View>*/}
                        {/* </View> */}
                    </View>
                    <View style={{flex: 5, justifyContent: 'center', alignItems: 'center', marginTop:"8%"}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.submitDetails}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Submit</Text>
                        </TouchableOpacity>
                    </View>
                    
                    <Modal
                        isVisible={this.state.displayModal == true}
                        animationInTiming={2000}
                        animationOutTiming={2000}
                        backdropTransitionInTiming={2000}
                        backdropTransitionOutTiming={2000}
                        >
                        {this.showDetialsInModal()}
                    </Modal>
                </ScrollView>
                <Footer/>
            </View>
        )
    }
}