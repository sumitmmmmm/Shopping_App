

import React from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView, KeyboardAvoidingView} from 'react-native';
import { Actions } from 'react-native-router-flux';
import global from '../../staticData/globalConfigurationFile';
import Modal from 'react-native-modal'
// import Map from '../../Map/map'
import * as citizenList from '../../staticData/citizenList';
import Footer from '../../Footer/footer';

export default class CitizenList extends React.Component{
    constructor(props){
        super(props);
     
        this.state = {
            citizenList: [],
            displayModal: false,
            detailsDisplayed: '',
            categoryName : this.props.categories,
            token: ''
        }

        AsyncStorage.getItem('jwtToken')
        .then(response => JSON.parse(response))
        .then(json => {
            console.log(json)
            this.setState({
                token: json
            })
            fetch(global.ipAddr + global.consumers, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': json
                }
            })
            .then(response => response.json())
            .then(json => {
                this.setState({
                    citizenList: json
                })
            })
        })


        
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;


    displayDetails = (value, index) => {
        this.setState({
            detailsDisplayed: value,
            displayModal: true
        })
    }

    scheduleDelivery =() => {
        Actions.ScheduleRationDeliveryScreen({citizenList : this.state.citizenList, categoryName: this.state.categoryName});
    }

    citizenDetailsDisplayerModal = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#003399', borderRadius: 40, height: this.height*0.5}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({displayModal: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <Image style={{ resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 10, justifyContent: 'center', alignItems: 'center'}}>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                    <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Details of the citizen are as follows: </Text>
                </View>
                <View style={{ justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Name</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.FirstName} {this.state.detailsDisplayed.LastName}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Mobile Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.MobileNo}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Ration Card Number</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.RationNo}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', fontStyle: 'italic', color: '#fff'}}>Age</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.Age}</Text>
                        </View>

                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold',  fontStyle: 'italic', color: '#fff'}}>Category</Text>
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>{this.state.detailsDisplayed.Category}</Text>
                        </View>
                        </View>
                    </View>
                </View>
            </View>
        )
    }

    renderCitizenList = (value, index) => {
        return(
            <View key={index} style={{justifyContent: 'center', alignItems: 'center',paddingVertical: '2%'}}>
                
                <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', backgroundColor: '#003399', width:this.width*0.95, borderRadius: 10}} onPress={() => this.displayDetails(value, index)}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.FirstName} {value.LastName}</Text>
                    </View>
                    <View style={{flex: 1,justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.MobileNo}</Text>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                        <Text style={{fontSize: 12, color: '#fff'}}>{value.RationNo}</Text>
                    </View>
                </TouchableOpacity>

            </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center'}}>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop:"15%"}}>
                    <Image style={{resizeMode: 'contain',width: 50, height: 50}} source={require('../../../../assets/wb_govt.png')} />
                </View>
                <View style={{flex: 10, justifyContent: 'center', alignItems: 'center', paddingTop: '2%', paddingHorizontal: '1%'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', marginHorizontal: 0.02*this.width,paddingBottom:0.03*this.height}}>
                        <Text style={{fontStyle: 15, fontWeight: 'bold', fontStyle: 'italic'}}>
                        The following citizens will receive an SMS on their registered mobile number to rations. 
                        Click on each citizen to view their details. Click on "Schedule Delivery" to continue</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', width: this.width*0.95}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Name</Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Mobile No.</Text>
                            </View>

                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 14, fontWeight: 'bold'}}>Ration Card No.</Text>
                            </View>
                        </View>
                    </View>
                    <ScrollView>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        {this.state.citizenList.map((value, index) => {
                            return(this.renderCitizenList(value, index))
                            
                        })}
                    </View>
                    </ScrollView>
                </View>
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginTop:"4%"}}>
                    <TouchableOpacity   style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} 
                                        onPress={this.scheduleDelivery}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Schedule Delivery</Text>
                    </TouchableOpacity>
                </View>
                

                <Modal
                    isVisible={this.state.displayModal == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.citizenDetailsDisplayerModal()}
                </Modal> 
                    <Footer/>
            </View>
        )
    }
}


