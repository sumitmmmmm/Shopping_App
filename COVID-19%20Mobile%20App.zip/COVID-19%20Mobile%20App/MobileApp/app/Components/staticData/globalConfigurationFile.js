const global = {
    ipAddr : "http://54.157.168.139:3002/api",
    sendMessage : "/Messages/sendMessage",
    district: "/Districts",
    subDivisions: "/SubDivisions",
    getToken: "/OwnerDetails/getToken",
    consumers: "/Consumers",
    schedules : "/Schedules",
    ownerDetails: "/OwnerDetails"
}

export default global;