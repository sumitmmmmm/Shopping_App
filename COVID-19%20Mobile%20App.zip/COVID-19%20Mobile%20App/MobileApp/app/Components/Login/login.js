import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'

export default class LoginScreen extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            modalDisplayer: false,
            OTP: '',
            OTPView: false,
            mobileNumber: '',
            selectedRole: '',
            roleValues: [
                {
                    value: 'Government'
                },
                {
                    value: 'Citizen'
                }
            ]
        }
        
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    onChangeValues = (value) => {
        this.setState({
            selectedRole: value
        })
    }

    handleMobileNumber = (value) => {
        this.setState({
            mobileNumber: value
        })
    }

    getOTP = () => {
        this.setState({
            OTPView: true
        })
    }

    handleOTP = (value) => {
        this.setState({
            OTP: value
        })
    }

    submitOTP = () => {
        this.setState({
            modalDisplayer: true
        })
    }

    login = () => {
        let loginDetails = {mobile: this.state.mobileNumber, selectedRole: this.state.selectedRole}
        AsyncStorage.setItem('loginDetails', JSON.stringify(loginDetails))
        .then(json => {
            console.log("MYMY", this.state.selectedRole);
            this.setState({
                modalDisplayer: false
            })
           
                Actions.CitizenListScreen()
            
        })
    }

    _renderModalForLogin = () => {
        return(
            <View style={{justifyContent: 'center', alignItems: 'center', backgroundColor: '#A9CCE3', borderRadius: 40, height: this.height*0.5}}>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                    <Image style={{width: 80, height: 80}} source={require('../../../assets/registered_successful_tick.png')} />
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                    <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic'}}>OTP verified successfully. You may now proceed to Login</Text>
                </View>
                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.login}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>LOGIN</Text>
                        </TouchableOpacity>
                </View>
            </View>
        )
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                {/* <View style={{justifyContent:'center', alignItems: 'center', flexDirection: 'row', marginRight: '10%'}}>
                    <View style={{flex: 2, justifyContent: 'center', alignItems: 'center'}}>
                        <Text style={{fontSize: 14, fontWeight: 'bold'}}>Role</Text>
                    </View>
                    <View style={{flex: 7, justifyContent: 'center', alignItems: 'center'}}>
                    <Dropdown
                            value={this.state.selectedRole}
                            data={this.state.roleValues}
                            // overlayStyle={{marginBotton: '5%'}}
                            // rippledCentered={true}
                            // pickerStyle={{borderBottomColor: 'transparent', borderWidth: 0}}
                            containerStyle={{borderWidth:1, borderColor: 'black', height: this.height*0.05, borderRadius:50, width:this.width*0.8, paddingLeft:this.width*0.02}}
                            dropdownOffset = { {top: 6, left: 0} }
                            onChangeText={(value) => {this.onChangeValues(value)}}
                        />
                    </View>
                </View> */}

                <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold'}}>Mobile Number</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '1%', width: this.width*0.9}}>
                        <TextInput
                              style={{borderColor: 'gray', borderRadius:10, borderWidth: 1, width: '100%', height: this.height*0.07}}
                              placeholder='Enter Mobile Number.'
                              value={this.state.mobileNumber}
                              onChangeText={this.handleMobileNumber}
                              keyboardType="number-pad"
                        />
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                        <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.getOTP}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Get OTP</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                {this.state.OTPView == true ?
                 <View style={{justifyContent: 'center', alignItems: 'center'}}>
                 <View style={{justifyContent: 'center', alignItems: 'center'}}>
                     <Text style={{fontSize: 15, fontWeight: 'bold', textAlign: 'center'}}>Enter OTP to Login</Text>
                 </View>
                 <View style={{justifyContent: 'center', alignItems: 'center', width: this.width*0.9}}>
                 <TextInput
                           style={{borderColor: 'gray', borderRadius:10, borderWidth: 1, width: '100%', height: this.height*0.07}}
                           placeholder='Enter OTP'
                           value={this.state.OTP}
                           onChangeText={this.handleOTP}
                           keyboardType="number-pad"
                     />
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '4%'}}>
                    <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.submitOTP}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Submit OTP</Text>
                        </TouchableOpacity>
                    </View>
                 </View>
             </View>: null}

             <Modal
          isVisible={this.state.modalDisplayer == true}
          animationInTiming={2000}
          animationOutTiming={2000}
          backdropTransitionInTiming={2000}
          backdropTransitionOutTiming={2000}
          >
            {this._renderModalForLogin()}
          </Modal>
               
            </View>
        )
    }
}