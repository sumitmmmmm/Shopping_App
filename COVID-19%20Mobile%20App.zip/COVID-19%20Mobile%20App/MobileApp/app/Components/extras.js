import React,{Component} from 'react';
import {View , Text , TextInput, StyleSheet,TouchableHighlight, TouchableOpacity, Image, AsyncStorage, Dimensions, ScrollView} from 'react-native';
import { Actions } from 'react-native-router-flux';
import MultiSelect from 'react-native-multiple-select';
import { Dropdown } from 'react-native-material-dropdown';
import Modal from 'react-native-modal'
import Map from '../Map/map'

export default class GovernmentScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            OTPconfirm: false,
            OTPModalDisplayer: false,
            OTP: '',
            OTPModalValue: '',
            OTPModalIndex: '',
            detailsDisplayer: false,
            detailsDisplayerValue: '',
            citizenSenderModalDisplayer: false,
            confirmedCitizenList: [],
            displayConfirmedCitizens: false,
            citizenList: [],
            selectedItems: [],
            cashQuantity: '',
            riceQuantity: '',
            wheatQuantity: '',
            barleyQuantity: '',
            pulsesQuantity: '',
            mobileNumber: '',
            role: '',
            items: [
                {
                    id: '8984321098',
                    name: '8984321098 - Satish Kumar',
                    displayName: 'Satish Kumar',
                    aadharNumber: '8986-5634-7895',
                    rationNumber: '1101123009',
                    age: '35',
                    address: 'Kolkata, India',
                    slot: '11:00 - 11:15 A.M'
                },
                {
                    id: '9056456321',
                    name: '9056456321 - Pavan Thakur',
                    displayName: 'Pavan Thakur',
                    aadharNumber: '3456-1098-5609',
                    rationNumber: '1101123010',
                    age: '42',
                    address: 'Kolkata, India',
                    slot: '11:30 - 11:45 A.M'
                },
                {
                    id: '9098976110',
                    name: '9098976110 - Rahul Mahajan',
                    displayName: 'Rahul Mahajan',
                    aadharNumber: '9054-4321-5600',
                    rationNumber: '1101123011',
                    age: '56',
                    address: 'Kolkata, India',
                    slot: '12:00 - 12:15 P.M'
                },
                {
                    id: '9900564311',
                    name: '9900564311 - Chetan Khanna',
                    displayName: 'Chetan Khanna',
                    aadharNumber: '9011-8743-0911',
                    rationNumber: '1101123012',
                    age: '39',
                    address: 'Kolkata, India',
                    slot: '12:15 - 12:30 P.M'
                },
                {
                    id: '8697843211',
                    name: '8697843211 - Satish Shloka',
                    displayName: 'Satish Shloka',
                    aadharNumber: '0999-9900-0101',
                    rationNumber: '1101123013',
                    age: '55',
                    address: 'Kolkata, India',
                    slot: '12:30 - 12:45 P.M'
                }
        ]
        }

        AsyncStorage.getItem('loginDetails')
        .then(res => JSON.parse(res))
        .then(loginDetails => {
            this.setState({
                mobileNumber: loginDetails.mobile,
                role: loginDetails.selectedRole
            })
        })
    }

    height = Dimensions.get("window").height;
    width = Dimensions.get("window").width;

    handleCashQuantity = (value) => {
        this.setState({
            cashQuantity: value
        })
    }

    handleRiceQuantity = (value) => {
        this.setState({
            riceQuantity: value
        })
    }

    handleWheatQuantity = (value) => {
        this.setState({
            wheatQuantity: value
        })
    }

    handleBarleyQuantity = (value) => {
        this.setState({
            barleyQuantity: value
        })
    }

    handlePulsesQuantity = (value) => {
        this.setState({
            pulsesQuantity: value
        })
    }

    sendToCitizen = () => {
        this.state.selectedItems.map((value, index) => {
            this.state.items.map((itemValue, itemIndex) => {
                if(value == itemValue.id){
                    this.setState(prevState => ({
                        citizenList: [...prevState.citizenList, itemValue]
                    }))
                }
            })
        })

        this.setState({
            citizenSenderModalDisplayer: true
        })
    }


    sendToSchedule = () => {
        Actions.ScheduleRationDeliveryScreen();   
    }


    handleOTP = (value) => {
        this.setState({
            OTP: value
        })
    }

    citizenSenderModal = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#FFF8DC', borderRadius: 40, height: this.height*0.5}}>
                <View style={{flex:2, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({citizenSenderModalDisplayer: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
               
                <View style={{flex: 20, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{ustifyContent: 'center', alignItems: 'center', paddingBottom: '5%'}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic'}}>The following citizens would be sent an SMS with a time slot for collection of their rations: Click on Submit to confirm</Text>
                    </View>
                    <View style={{flex: 18, justifyContent: 'center', alignItems: 'center'}}>
                    <ScrollView contentContainerStyle={{justifyContent: 'center', alignItems: 'center', width: this.width*0.95}}>
                    {this.state.citizenList.map((citizenValue, citizenIndex) => {
                        return(
                            <View key={citizenIndex} style={{justifyContent: 'center', alignItems: 'center',  borderWidth: 1, backgroundColor: '#FAEBD7', paddingVertical: '3%'}}>
                                
                                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Name: </Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>{citizenValue.displayName}</Text>
                                    </View>
                                </View>

                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Mobile Number: </Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>{citizenValue.id}</Text>
                                    </View>
                                </View>

                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Ration Card Number: </Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>{citizenValue.rationNumber}</Text>
                                    </View>
                                </View>

                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Age: </Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>{citizenValue.age}</Text>
                                    </View>
                                </View>

                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Address: </Text>
                                    </View>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>{citizenValue.address}</Text>
                                    </View>
                                </View>
                                </View>
                             
                            </View>
                        )
                        
                    })}
                       </ScrollView>
                    </View>
                </View>

                <View style={{flex: 5, justifyContent: 'center', alignItems: 'center'}}>
                    <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.submitDetails}>
                        <Text style={{fontSize: 13, fontWeight: 'bold', color: '#fff'}}>Submit</Text>
                    </TouchableOpacity>
                </View>

            </View>
        )
    }

    submitDetails = () => {
        this.setState({
            citizenSenderModalDisplayer: false,
            confirmedCitizenList: this.state.citizenList,
            displayConfirmedCitizens: true
        })
    }

    cancelTransaction = () => {
        this.setState({
            modalDisplayer: false
        })
    }

    logOut = () => {
        Actions.LoginScreen()
    }

    confirmTransaction = () => {

        if(this.state.riceQuantity == ''){
            this.state.riceQuantity = 0
        }

        if(this.state.wheatQuantity == ''){
            this.state.wheatQuantity = 0
        }

        if(this.state.barleyQuantity == ''){
            this.state.barleyQuantity = 0
        }

        if(this.state.pulsesQuantity == ''){
            this.state.pulsesQuantity = 0
        }

        let today = new Date();
        let date = today.getDate() + '/' + (today.getMonth()+1) + '/' + today.getFullYear();

        let resourcesSent = {rice: this.state.riceQuantity, wheat: this.state.wheatQuantity, barley: this.state.barleyQuantity, pulses: this.state.pulsesQuantity, cash: this.state.cashQuantity, date: date, location: 'Kolkata, India'}

        AsyncStorage.setItem('latestResource', JSON.stringify(resourcesSent))

        AsyncStorage.getItem('sentResources')
        .then(res => JSON.parse(res))
        .then(resourceHistory => {
            console.log("MEGA", (resourceHistory))
            if(resourceHistory == null){
                let firstTimePush = [];
                firstTimePush.push(resourcesSent);
                AsyncStorage.setItem('sentResources', JSON.stringify(firstTimePush))
                .then(response => {
                    this.setState({
                        modalDisplayer: false
                    })
                })
            }
            else{
                resourceHistory.push(resourcesSent);
                AsyncStorage.setItem('sentResources', JSON.stringify(resourceHistory))
                .then(response => {
                    this.setState({
                        modalDisplayer: false
                    })
                })
            }
            
        })
    }

    onSelectedItemsChange = (selectedItems, index) => {
        console.log("SELECT", index)
        this.setState({selectedItems: selectedItems})
    }

 
    detailsDisplayerModal = () => {
        console.log("HEELO", this.state.detailsDisplayerValue)
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#FFF8DC', borderRadius: 40, height: this.height*0.5}}>
                <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({detailsDisplayer: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>
                <View style={{flex: 20, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center', paddingBottom: '5%'}}>
                        <Text style={{fontSize: 20, fontWeight: 'bold'}}>Customer Details</Text>
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Name: </Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.detailsDisplayerValue.displayName}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Mobile No.: </Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.detailsDisplayerValue.id}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Ration Card Number: </Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.detailsDisplayerValue.rationNumber}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Age: </Text>
                        </View>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.detailsDisplayerValue.age}</Text>
                        </View>
                    </View>

                    <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%'}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Address: </Text>
                        </View>
                        <View style={{flex: 1,justifyContent: 'center', alignItems: 'center'}}>
                            <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.detailsDisplayerValue.address}</Text>
                        </View>
                    </View>
                </View>
            </View>
        )
    } 

    displayDetails = (value) => {
        console.log(value)
        this.state.items.map((itemValue, itemIndex) => {
            if(itemValue.id == value){
                this.setState({
                    detailsDisplayer: true,
                    detailsDisplayerValue: itemValue
                })
                
                
            }
        })
    }

    openModalForConfirmedOTP = (value, index) => {
        this.setState({
            OTPModalDisplayer: true,
            OTPModalValue: value,
            OTPModalIndex: index,
            OTPconfirm: false
        })
    }

    getOTP = () => {
        this.setState({
            OTPconfirm: true
        })
    }

    OTPModal = () => {
        return(
            <View style={{justifyContent: 'center', backgroundColor: '#FFF8DC', borderRadius: 40, height: this.height*0.5}}>
                 <View style={{flex:1, alignItems: 'flex-end', marginRight: '5%', marginTop: '5%'}}>
                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.04, width: this.height*0.04, borderRadius: this.height*0.02, backgroundColor: '#fff'}} onPress={() => {this.setState({OTPModalDisplayer: false})}}>
                        <Text style={{fontSize: 15, fontWeight: 'bold', color: 'red'}}>X</Text>
                    </TouchableOpacity>
                </View>

                <View style={{flex: 20, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Name: </Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.OTPModalValue.displayName}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Mobile Number: </Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.OTPModalValue.id}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Ration Card Number: </Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.OTPModalValue.rationNumber}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Age: </Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.OTPModalValue.age}</Text>
                            </View>
                        </View>

                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>Address: </Text>
                            </View>
                            <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>{this.state.OTPModalValue.address}</Text>
                            </View>
                        </View>
                    </View>

                    {this.state.OTPconfirm == false ? 
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 15, fontWeight: 'bold'}}>Enter OTP to confirm ration transaction for the above customer: </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center', width: this.width*0.5, paddingTop: '4%'}}>
                                <TextInput
                                    style={{borderColor: 'gray', borderRadius:10, borderWidth: 1, width: '100%', height: this.height*0.07}}
                                    placeholder='Enter OTP'
                                    value={this.state.OTP}
                                    onChangeText={this.handleOTP}
                                    keyboardType="number-pad"
                                />
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.getOTP}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Submit</Text>
                            </TouchableOpacity>
                        </View>
                        </View>: null}
                        
                    {this.state.OTPconfirm == true ? 
                        <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '5%'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Image style={{width: 80, height: 80}} source={require('../../../assets/registered_successful_tick.png')} />
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold', fontStyle: 'italic'}}>OTP confirmed. Click on OK to Continue</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'flex-end', paddingVertical: '4%'}}>
                            <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.confirmOTP}>
                                <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>OK</Text>
                            </TouchableOpacity>
                        </View>
                        </View>
                        :null
                        }
                </View>
            </View>
        )
    }

    confirmOTP = () => {
        this.state.confirmedCitizenList.map((value, index) => {
            if(value.id == this.state.OTPModalValue.id){
                this.state.confirmedCitizenList.splice(index, 1);
            }
        })
        this.setState({
            OTPModalDisplayer: false
        })
    }

    render(){
        return(
            <View style={{flex: 1, justifyContent: 'center', marginTop: '5%'}}>
                
                <View style={{flex: 2, flexDirection: 'row', alignItems: 'center'}}>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-start', paddingVertical: '3%', paddingHorizontal: '3%'}}>
                    
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>User ID: </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 10}}>{this.state.mobileNumber}</Text>
                            </View>
                        </View>
                        <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold'}}>Role:  </Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                <Text style={{fontSize: 10}}>{this.state.role}</Text>
                            </View>
                    
                        </View>
                    </View>
                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'flex-end', paddingHorizontal: '3%'}}>
                    <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#DC143C'}} onPress={this.logOut}>
                            <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>LogOut</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <View style={{flex: 8, justifyContent: 'center', alignItems: 'center'}}>
                    <Map />
                </View>
                
                <View style={{flex: 20, width: this.width, justifyContent: 'center', alignItems: 'center', paddingVertical: '6%', borderRadius: 20, backgroundColor: '#F5F5DC'}}>
                <View style={{ width: this.width*0.8, borderRadius: 20, zIndex: 999}}>
                    <MultiSelect
                        hideTags
                        items={this.state.items}
                        uniqueKey="id"
                        ref={(component) => { this.multiSelect = component }}
                        onSelectedItemsChange={(value, index) => this.onSelectedItemsChange(value, index)}
                        selectedItems={this.state.selectedItems}
                        selectText="Pick Items"
                        searchInputPlaceholderText="Search Items..."
                        onChangeInput={ (text)=> console.log(text)}
                        tagRemoveIconColor="#CCC"
                        tagBorderColor="#CCC"
                        tagTextColor="#CCC"
                        selectedItemTextColor="#003399"
                        selectedItemIconColor="#CCC"
                        itemTextColor="#000"
                        displayKey="name"
                        styleDropdownMenuSubsection={{borderRadius: 20}}
                        styleSelectorContainer={{borderRadius: 20}}
                        styleTextDropdownSelected={{fontStyle: 'italic'}}
                        searchInputStyle={{ color: '#CCC' }}
                        submitButtonColor="#003399"
                        submitButtonText="Submit"
                    
                    />
                    </View>
                    <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                    <Text style={{fontSize: 15, fontWeight: 'bold', fontStyle: 'italic'}}>The following numbers would be sent SMS for collecting their rations. Select the number to view their details:</Text>
                                </View>
                    {this.state.selectedItems.map((value, index) => {
                        return(
                            <View key={index} style={{justifyContent: 'center', alignItems: 'center'}}>
                                
                                    <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderRadius: 20, width: this.width*0.8, paddingVertical: '1%', marginTop: '2%'}} onPress={() => this.displayDetails(value)}>
                                        <Text style={{fontSize: 13, fontWeight: 'bold', textAlign: 'center', marginBottom: '3%'}}>{value}</Text>
                                    </TouchableOpacity>
                                
                            </View>
                        )
                    })} 
                    
               
                </View>



                

                {this.state.displayConfirmedCitizens == true ?
                <View style={{flex: 10, justifyContent: 'center', alignItems: 'center'}}>
                    <ScrollView contentContainerStyle={{justifyContent: 'center', alignItems: 'center', width: this.width*0.95}}>
                        <View style={{justifyContent: 'center', alignItems: 'center', width: this.width*0.8}}>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '2%'}}>
                                <Text style={{fontSize: 12, fontWeight: 'bold',  fontStyle: 'italic'}}>The following customers were sent an SMS for collection of their rations at the mentioned times. Click on the citizen to give them their resources.</Text>
                            </View>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingBottom: '2%'}}>
                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold'}}>Sl. No.</Text>
                                    </View>
                                    <View style={{flex: 3, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold'}}>Name</Text>
                                    </View>
                                    <View style={{flex: 3, justifyContent: 'center', alignItems: 'center'}}>
                                        <Text style={{fontSize: 12, fontWeight: 'bold'}}>Time Slot</Text>
                                    </View>
                                </View>
                            </View>
                            {this.state.confirmedCitizenList.map((value, index) => {
                                return(
                                    <View key={index} style={{justifyContent: 'center', alignItems: 'center', marginTop: '2%'}}>
                                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                                            <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row', paddingVertical: '2%', backgroundColor: '#FFE4C4', borderRadius: 15}} onPress={() => this.openModalForConfirmedOTP(value, index)}>
                                                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', marginBottom: '4%'}}>
                                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>{index+1}</Text>
                                                </View>
                                                <View style={{flex: 3, justifyContent: 'center', alignItems: 'center', marginBottom: '4%'}}>
                                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>{value.displayName}</Text>
                                                </View>
                                                <View style={{flex: 3, justifyContent: 'center', alignItems: 'center', marginBottom: '4%'}}>
                                                    <Text style={{fontSize: 12, fontWeight: 'bold'}}>{value.slot}</Text>
                                                </View>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                )
                            })}
                        </View>
                    </ScrollView>
                </View>
                :null
                }

                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', paddingTop: '7%'}}>
                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.sendToCitizen}>
                    <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>Send to Citizen</Text>
                </TouchableOpacity>
                </View>


                <View style={{flex: 2, justifyContent: 'center', alignItems: 'center', paddingTop: '7%'}}>
                <TouchableOpacity style={{paddingVertical: '3%', paddingHorizontal: '5%', borderRadius: 10, backgroundColor: '#003399'}} onPress={this.sendToSchedule}>
                    <Text style={{color: '#fff', fontWeight: 'bold', fontSize: 15}}>SCHEDULE</Text>
                </TouchableOpacity>
                </View>
                

                <Modal
                    isVisible={this.state.detailsDisplayer == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.detailsDisplayerModal()}
                </Modal>

                <Modal
                    isVisible={this.state.citizenSenderModalDisplayer == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.citizenSenderModal()}
                </Modal>

                <Modal
                    isVisible={this.state.OTPModalDisplayer == true}
                    animationInTiming={2000}
                    animationOutTiming={2000}
                    backdropTransitionInTiming={2000}
                    backdropTransitionOutTiming={2000}
                    >
                    {this.OTPModal()}
                </Modal>


            </View>
        )
    }
}