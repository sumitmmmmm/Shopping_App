import React from 'react';
import { Dimensions, Text,TextInput, ScrollView ,View,Image,Button,TouchableOpacity, Animated,TouchableHighlight,KeyboardAvoidingView,StatusBar, Alert, AsyncStorage} from 'react-native';
import LandingPageStyle from './menuPageStyle';
import { Actions } from 'react-native-router-flux';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faCalendarAlt, faHandHoldingHeart, faQuestion } from '@fortawesome/free-solid-svg-icons';
import Footer from '../Footer/footer'


export default class LandingPageScreen extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            
        }

    }

    width = Dimensions.get('window').width;
    height = Dimensions.get('window').height;

    scheduleDelivery = () => {
        Actions.CategorySelection();
    }

    makeDelivery = () => {
        Actions.DeliverRation();
    }  

    alertMessageForScheduleDelivery = () => {

        Alert.alert(
            
            'Schedule Delivery',
            'Schedule Time and Date of all citizens within your area for picking up their respective rations',
            [
              {text: 'OK', onPress: () => console.log('OK')},
            ],
            { cancelable: true }
          );
    }

    alertMessageForMakeDelivery = () => {

        Alert.alert(
            
            'Make Delivery',
            'Deliver rations to citizens at their specified slot by verifying OTP sent to their registered mobile numbers',
            [
              {text: 'OK', onPress: () => console.log('OK')},
            ],
            { cancelable: true }
          );
    }

    

    render ( ) {
        
        return(
            <View style={{flex:1}}>

                
                
                <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                    <View style={{flex: 1, marginTop:"15%"}}>
                        <View style={{justifyContent: 'center', alignItems: 'center'}}>
                            <Image style={{resizeMode: 'contain',width: 50, height: 50}} source={require('../../../assets/wb_govt.png')} />
                        </View>
                    </View>
                    <View style = {{flex: 1, marginTop:0.05*this.height,  justifyContent: 'center'}} >
                            <Text style={LandingPageStyle.productDetailsHeader}> Choose Option  </Text>
                    </View>

                    <View style={{flex: 12, justifyContent: 'center', alignItems: 'center', flexDirection: 'row', marginBottom: 0.2*this.height}}>
                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <TouchableOpacity   style={LandingPageStyle.buttonStyle} 
                                                onPress={this.scheduleDelivery}>
                                <FontAwesomeIcon icon={faCalendarAlt} size={70} style={{color:"#fff"}}/>
                            </TouchableOpacity>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '15%'}}>
                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <Text style={{fontSize: 15, fontWeight: 'bold', paddingHorizontal: '2%'}}>Schedule Delivery</Text>
                                        <View style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.03, width: this.height*0.03, borderRadius: this.height*0.015, backgroundColor: '#003399', marginTop: '1%'}}>
                                            <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center'}} onPress={this.alertMessageForScheduleDelivery}>
                                                
                                                <FontAwesomeIcon icon={faQuestion} size={10} style={{color:"#fff"}}/>
                                            </TouchableOpacity>
                                            
                                        </View>
                                </View>
                                
                            </View>
                            
                        </View>

                        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
                            <TouchableOpacity   style={LandingPageStyle.buttonStyle} 
                                                onPress={this.makeDelivery}>
                                <FontAwesomeIcon icon={faHandHoldingHeart} size={70} style={{color:"#fff"}}/>
                            </TouchableOpacity>
                            <View style={{justifyContent: 'center', alignItems: 'center', paddingVertical: '15%'}}>
                                <View style={{justifyContent: 'center', alignItems: 'center', flexDirection: 'row'}}>
                                    <Text style={{fontSize: 15, fontWeight: 'bold', paddingHorizontal: '2%'}}>Make Delivery</Text>
                                        <View style={{justifyContent: 'center', alignItems: 'center', height: this.height*0.03, width: this.height*0.03, borderRadius: this.height*0.015, backgroundColor: '#003399', marginTop: '1%'}}>
                                            <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center'}}onPress={this.alertMessageForMakeDelivery}>
                                                <FontAwesomeIcon icon={faQuestion} size={10} style={{color:"#fff"}}/>
                                            </TouchableOpacity>
                                        </View>
                                </View>
                                
                            </View>
                        </View>
                        
                    </View>
                    
                       
                   
                </View>
                <Footer />
            </View>
        )
    }
}