import {StyleSheet} from 'react-native';
import {Dimensions} from 'react-native';

let height = Dimensions.get("window").height;
let width = Dimensions.get("window").width;

export default StyleSheet.create({
    productDetailsHeader:{
        backgroundColor: 'white',
        color: '#003399',
        fontWeight: 'bold',
        fontSize:25, 
        textAlign:"center",
        marginLeft:'5%'
    },
    buttonStyle: {
        height: height*0.15,
        width: height*0.15,
        borderRadius: height*0.75, 
        backgroundColor: '#003399',
        justifyContent: 'center',
        alignItems: 'center'
    },
    buttonText:{
        fontSize: 18, 
        fontWeight: 'bold', 
        color: '#fff',
        textAlign: 'center'
    },
})