import React, { Component } from 'react';
import {
  View,
  TouchableOpacity,
  Image, 
  Text,
  KeyboardAvoidingView,   
  AsyncStorage
} from 'react-native';
import { Actions } from 'react-native-router-flux';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faHome, faBookOpen, faHandHolding, faBell, faCalendarCheck, faUser, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import MenuPageScreen from '../MenuPage/menuPage';
import RequestStatus from '../Government/RequestStatus/RequestStatus';
import RescheduleDelivery from '../Government/RescheduleDelivery/rescheduleDelivery';
import FooterStyle from './footerStyle';
// import FooterStyle from '../registerProduct/FooterStyle';

const currentDate = new Date();
const date = currentDate.getDate()+'-'+(currentDate.getMonth()+1)+'-'+currentDate.getFullYear();

export default class Footer extends React.Component {
    constructor(props){
        super(props);
        

        this.state={
            batchNumberForMessage: props.notificationMessageDisplay,
            visibleModal: null,
            footerResponse: {},
        }
        // console.log(this.state.batchNumberForMessage);
    }

    logout = () => {
        Actions.LandingPage()
    }

    render() {
     
        gotoMenuPage = () => {
            Actions.MenuPageScreen()
        }
       
        gotoReschedule = () => {
            Actions.RescheduleDelivery()
        }
        return(
        <View style={FooterStyle.parentContainer}>
        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity onPress={gotoMenuPage}>
                <Image style={{width:35,height:35 }} source={require('../../../assets/images/Footer/bottom_home_select.png')}/>
            </TouchableOpacity>
        </View>
        
        <View style={FooterStyle.imageStyle} >
            <TouchableOpacity onPress={gotoReschedule}>
                <FontAwesomeIcon icon={faCalendarCheck} size={35} style={{color:"#fff"}}/>
            </TouchableOpacity>
        </View>
        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity>
                <FontAwesomeIcon icon={faUser} size={35} style={{color:"#fff"}}/>
            </TouchableOpacity>
        </View>

        <View style={FooterStyle.imageStyle}>
            <TouchableOpacity onPress={this.logout}>
                <FontAwesomeIcon icon={faSignOutAlt} size={35} style={{color:"#fff"}}/>
            </TouchableOpacity>
        </View>
      
        </View> 
        )
    }
  }