const promisify = require('promisify-es6');
const scheduler = require('node-schedule');
let LoopbackContext = require('loopback-context');

module.exports = function(Schedule){
    Schedule.bulkSave = function(ctx, data, next){
        if(data && data.length){
            Schedule.create(data).then((res)=>{
                // data.forEach((element,index) => {
                //     promisify(Schedule.app.models.Message.sendMessage)(ctx, {"Mobile":"8447271729","Message":"This is a dummy message "+index}).then((result)=>{
                //         console.log("result:::",result.response.statusCode)
                //     })
                // });
                next(null, res);
            }).catch((err)=>{
                next(err);
            })
        } else {
            next();
        }
    }
    let months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    scheduler.scheduleJob('1 */10 * * * *', function(){
    Schedule.find({where:{or:[{MessageStatus:null},{MessageStatus:"FAILED"}]},limit:50}).then((records)=>{
        let LoopBackContext = LoopbackContext.getCurrentContext({ bind: true });
        records.map((aRecord, index)=>{
            promisify(Schedule.app.models.Message.sendMessage)(LoopBackContext, {"Mobile":aRecord.Mobile,"Message":"Dear "+aRecord.CustomerName+", Please visit your allocated ration centre (A.C.ROY 704409XXXX) on "+new Date("2020-05-04").getDate()+"th "+months[new Date("2020-05-04").getMonth()]+" "+new Date("2020-05-04").getFullYear()+"(Monday)"+" at 10:10 AM and collect your ration. DFPD, GoWB #BengalfightsCorona"}).then((result)=>{
                console.log("result:::",result.response.statusCode,aRecord.ScheduleId);
                if(result.response.statusCode===200){
                    Schedule.updateAll({ScheduleId:aRecord.ScheduleId},{MessageStatus:"PASSED"})
                } else {
                    Schedule.updateAll({ScheduleId:aRecord.ScheduleId},{MessageStatus:"FAILED"})
                }
            })
        })
    })
    })



    Schedule.remoteMethod('bulkSave', {
        "accepts": [{arg:"ctx",type:"object",http:{source:"context"}},{arg: 'data', type: 'array', 'http': {source: 'body'}}],
        "returns": { "arg": "data","type":"object",root:true},
        "http": {"verb": "POST", "path": "/bulk"},
        "accessType":"WRITE"
    });

}