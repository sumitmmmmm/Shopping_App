module.exports = function(SubDivisions){
    
}