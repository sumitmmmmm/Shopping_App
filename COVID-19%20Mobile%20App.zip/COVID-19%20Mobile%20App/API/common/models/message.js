const request = require('request');

module.exports = function(Message) {
  Message.sendMessage = function(ctx, data, next) {
    console.log(data);
    if(data.Mobile) {
      request(
        {
          method:'POST',
          rejectUnauthorized:false,
          url:'https://sms.nltr.org/send_sms_food.php',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          form: {
            'mobile': data.Mobile,
            'message': data.Message
          }
        }, function(err, response) {
            if (err) {
              console.log("err" , err);
              next(null, err);
            }
            next(null, {response});
        }
      );
    } else {
      let msg = {error : "Please enter a vaild mobile number or message"};
      next(null, msg);
    }
  }

  Message.remoteMethod('sendMessage', {
    "accepts": [{arg:"ctx",type:"object",http:{source:"context"}},{arg: 'data', type: 'object', 'http': {source: 'body'}}],
    "returns": { "arg": "data","type":"object",root:true},
    "http": {"verb": "POST", "path": "/sendMessage"},
    "accessType":"WRITE"
  });
}