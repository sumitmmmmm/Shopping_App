let passport = require("passport")
let jwt = require("jsonwebtoken");

module.exports = function(OwnerDetails){
  OwnerDetails.validateUser = function(ctx, data, next) {
    console.log('data::',data);  
    if(data.Username && data.Password) {
        OwnerDetails.findOne({where:{MobileNo:data.Username,Password:data.Password}})
        .then((aUser)=>{
            console.log('user:::',aUser)
            if(aUser){
                let expiration_time = 7200;
                let token = {"Token":"JWT "+jwt.sign({user_id:aUser.OwnerId}, 'jwt_please_change', {expiresIn: 14400,})};
                next(null, token);
            } else {
               let msg = {"message":"User not found"}
               next(null, msg)
            }
        }).catch((err)=>{
            next(err);
        })
    } else {
        let msg = {"message":"Please provide Username and Password"}
        next(null, msg)
    }
  }

  OwnerDetails.remoteMethod('validateUser', {
    "accepts": [{arg:"ctx",type:"object",http:{source:"context"}},{arg: 'data', type: 'object', 'http': {source: 'body'}}],
    "returns": { "arg": "data","type":"object",root:true},
    "http": {"verb": "POST", "path": "/getToken"},
    "accessType":"WRITE"
  });
};