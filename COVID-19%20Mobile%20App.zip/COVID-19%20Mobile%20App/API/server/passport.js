let app = require('./server');
const { ExtractJwt, Strategy } = require('passport-jwt');
const passport = require('passport');

module.exports = function(){
    var opts = {
      jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme('JWT'),
      secretOrKey: 'jwt_please_change'
    };
    // opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
    // opts.secretOrKey = 'jwt_please_change';
    passport.use(
      'jwt',
      new Strategy(opts, (jwt_payload, done) => {
        try {
          app.models.OwnerDetails.findOne({where:{OwnerId:jwt_payload.user_id}})
          .then((aUser) => {
            if (aUser) {
              console.log("user found");
              return done(null, aUser);
            } else {
              console.log("User not found");
              return done(null, false);
            }
          })
        } catch (err) {
          done(err);
        }
      })
    );

    // passport.serializeUser(function (user, done) {
    //     done(null, user._id);
    // });
    
    /*passport.deserializeUser(function (user, done) {  
        authService.findByUserId(user._id,function (err, user) {
            done(err, user);
        });
    });*/
}