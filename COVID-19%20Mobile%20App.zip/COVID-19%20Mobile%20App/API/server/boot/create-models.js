module.exports = function(app) {
  // if(!app.models.LaunchpadContent){
  //   app.dataSources.dealdashboard.automigrate('LaunchpadContent', function(err) {
  //       console.log('Created model')
  //     if (err) throw err;
  
  //   //   app.models.CoffeeShop.create([{
  //   //     name: 'Bel Cafe',
  //   //     city: 'Vancouver'
  //   //   }, {
  //   //     name: 'Three Bees Coffee House',
  //   //     city: 'San Mateo'
  //   //   }, {
  //   //     name: 'Caffe Artigiano',
  //   //     city: 'Vancouver'
  //   //   }], function(err, coffeeShops) {
  //   //     if (err) throw err;
  
  //       // console.log('Models created: \n', coffeeShops);
  //   //   });
  //   });
  // }
  // if(!app.models.Projects){
  //   app.dataSources.dealdashboard.automigrate('Projects', function(err) {
  //       console.log('Created model')
  //     if (err) throw err;
  //   });
  // } 
};