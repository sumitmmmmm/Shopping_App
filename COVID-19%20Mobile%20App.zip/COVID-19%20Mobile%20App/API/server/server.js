var loopback = require('loopback');
var boot = require('loopback-boot');
var bodyParser = require('body-parser');
const passport = require('passport');

var app = module.exports = loopback();
var port = process.env.PORT || 80;

app.use(bodyParser.json({limit:"50mb"}));
app.use(bodyParser.urlencoded({ extended: true, limit:'50mb'}));
app.use(passport.initialize());
app.use(passport.session());

boot(app, __dirname);
app.start = function() {
  // start the web server
  return app.listen(port,function() {
    app.emit('started');
    var baseUrl = app.get('url').replace(/\/$/, '');
    console.log('Web server listening at: %s', baseUrl);
    if (app.get('loopback-component-explorer')) {
      var explorerPath = app.get('loopback-component-explorer').mountPath;
      console.log('Browse your REST API at %s%s', baseUrl, explorerPath);
    }
  });
};
