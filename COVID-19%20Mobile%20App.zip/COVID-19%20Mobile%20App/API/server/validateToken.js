let app = require('./server');
let request = require('request');
let LoopbackContext = require('loopback-context');
const { ExtractJwt, Strategy } = require('passport-jwt');
const passport = require('passport');
require('./passport')(passport)

module.exports = function(){
    return function (req, res, next) {
        if (req.url == "/OwnerDetails/getToken" || req.url == "/Messages/sendMessage") {
          next();
        } else {
          passport.authenticate('jwt', {session:false}, (err, user, info) => {
            if (err) {
              res.status(401).send(err);
            }
            if (info != undefined) {
              res.status(401).send(info);
            } else {
              next();
            }
          })(req, res, next);
        }
    }
}
